source: sampscan.asm

; ===========================================================================
; === Sample RAM scan  (C) Cybernetic 1997
; === 
 
; NOTE: will will not function correctly on 7.12 mhz and R800! (Music Module
;       will not accept high data-rates!)
 
; I/O Ports:
MM_REG: EQU   &HC0            ;Music Module REGister select port
MMDATA: EQU   &HC1            ;Music Module DATA input/output pport
 
; ===========================================================================
; Scan Music Module's Sample RAM
; IN     : F:Z  = no Music Module present
;            NZ =    Music Module present!
;          IX   = number of detected 1 kB Sample RAM segments (0 .. 256)
; PRECON : -
; OUT    : -
; POSTCON: - Music Module has been initialized and Sample RAM has been
;            scanned (non-destructive).
; USES   : A,B,C,D,E,F,H,L
; CALLS  : MM_OUT
 
BACKUP: DW    0,0,0           ;BACK-UP sample ram data
RESETD: DW    0,0             ;RESET Data (all 0's)
CHECKD: DB    "sCaN"          ;CHECK Data string (4 bytes)
READRS: DW    0,0,0           ;READ ReSult
 
SMPCHK: ;SaMPle ram CHecK
        LD    IX,0            ;reset RAM-segment counter
 
        CALL  INITMM          ;is there a Music-Module present? (first make
                              ;shure the status-register will have a value
                              ;non-equal to: 255)
 
        IN    A,(MM_REG)      ;if result is still 255 then no Music-Module
        INC   A               ;present!
        RET   Z
 
        LD    B,0             ;scan a maximum of 256 Sample RAM segments
 
; Scan loop
LOOP_1: PUSH  BC              ;save loop-counter
 
        LD    HL,BACKUP       ;first make a back-up (non-destructive scan!)
        LD    BC,6*256+&H20
        PUSH  BC              ;(save to re-use)
        CALL  RWSAMP
 
        LD    HL,RESETD       ;make shure the ID-string is not accidently
        LD    BC,4*256+&H60   ;present
        PUSH  BC              ;(save to re-use)
        CALL  RWSAMP
 
        LD    HL,CHECKD       ;write ID-string into Sample RAM
        POP   BC
        CALL  RWSAMP
 
        LD    HL,READRS       ;try to read ID-string back...
        POP   BC              ;(re-use)
        CALL  RWSAMP
 
        LD    HL,BACKUP+2     ;write back-up back into Sample RAM
        LD    BC,4*256+&H60
        CALL  RWSAMP
 
        LD    B,4             ;compare result with original
        LD    HL,CHECKD       ;set pointer to ID-string
        LD    DE,READRS+2     ;set pointer to read result
 
LOOP_2: LD    A,(DE)          ;compare the 2 strings
        CP    (HL)
        JR    NZ,JUMP_2
        INC   HL
        INC   DE
        DJNZ  LOOP_2
 
        INC   IX              ;successfully scanned a segment!
 
        POP   BC              ;scan another RAM-segment?
        DJNZ  LOOP_1
 
JUMP_1: XOR   A               ;end of loop, return with NZ
        INC   A
        RET
 
JUMP_2: POP   BC              ;remove loop counter from stack!
        JR    JUMP_1          ;and return with NZ
 
 
; ===========================================================================
; Read/write data from/into Sample RAM
; IN     : HL -> destination/source pointer
;          B  =  number of bytes to read/write (4 or 6)
;          C  =  select: &H60 = write data to   Sample RAM
;                        &H20 = read  data from Sample RAM
;          IX =  Sample RAM-segment to scan (0 .. 255)
; PRECON : - source buffer contains data to write into Sample RAM.
; OUT    : -
; POSTCON: - destination buffer contains 2 'dummy' bytes + Sample
;            RAM data.
; USES   : A,B,C,D,E,F,H,L
; CALLS  : INITMM, MM_OUT
 
RWSAMP: ;Read/Write SAMPLE ramle
        LD    A,I             ;disable interrupts!
        DI
        PUSH  AF
 
        PUSH  HL              ;(save counters and pointer)
        PUSH  BC
 
        CALL  INITMM          ;init Music Module
 
        PUSH  IX              ;set high-byte of begin address
        POP   HL
        LD    D,L
        LD    E,10
        CALL  MM_OUT
        LD    E,12            ;and of end address
        CALL  MM_OUT
 
        POP   BC              ;retrieve counters and pointer
        POP   HL
 
        LD    E,7             ;select desired ADPCM-control mode
        LD    D,C
        CALL  MM_OUT
 
        LD    DE,&H70*256+4   ;enable Buffer Ready interrupt
        CALL  MM_OUT
 
; Read/write loop...
LOOP_3: LD    A,&H0F          ;select ADPCM I/O register
        OUT   (MM_REG),A
        BIT   6,C             ;read or write?
        JR    Z,JUMP_3
        LD    A,(HL)          ;write a byte to Sample RAM
        OUT   (MMDATA),A
        JR    JUMP_4
JUMP_3: IN    A,(MMDATA)      ;read a byte from Sample RAM
        LD    (HL),A
JUMP_4:
        INC   HL              ;move data source/destination pointer
 
        LD    DE,&H80*256+4   ;reset all flags
        CALL  MM_OUT
 
        DEC   B               ;end of loop?
        JR    Z,JUMP_5
 
LOOP_4: IN    A,(MM_REG)      ;wait for any interrupt from Music Module
        BIT   7,A
        JR    Z,LOOP_4
        JR    LOOP_3          ;(it will always signal: 'buffer-ready')
 
JUMP_5: ; Shutdown Music Module
        LD    DE,&H78*256+4   ;mask all interrupts
        CALL  MM_OUT
        LD    A,&H80          ;reset all interrupt flags
        OUT   (MMDATA),A
 
        LD    DE,1*256+7      ;reset ADPCM-control
        CALL  MM_OUT
 
        POP   AF              ;enable interrupts again
        LD    I,A
        RET
 
 
; ===========================================================================
; Init Music Module
; IN     : -
; PRECON : -
; OUT    : -
; POSTCON: - Music Module has been inited.
; USES   : A,B,F,H,L
; CALLS  : -
 
INITMM: ;INIT Music Module
        LD    HL,REGSET
LOOP_5: LD    A,(HL)
        AND   A
        RET   Z
        LD    E,A
        INC   HL
        LD    D,(HL)
        INC   HL
        CALL  MM_OUT
        JR    LOOP_5
 
REGSET: DB    4,&H78,4,&H80   ;mask all flags and reset interrupts
        DB    7,&H01,8,&H00   ;reset ADPCM functions
        DB    9,&H00          ;set low-byte of begin address to :0
        DB    11,&H01         ;set low-byte of end   address to :1 (4 bytes!)
        DB    24,&H08         ;output control
        DB    0               ;end of data marker
 
 
; ===========================================================================
; Write to Music Module register (L:--Q6--)
; IN     : E = register #
;          D = new register data
; PRECON : -
; OUT    : -
; POSTCON: - contents of Music Module register has been changed.
; USES   : A
; CALLS  : -
 
MM_OUT: ;Music Module OUTput
        LD    A,E             ;specify register
        OUT   (MM_REG),A
        LD    A,D             ;write data
        OUT   (MMDATA),A
        RET

??



 

 

