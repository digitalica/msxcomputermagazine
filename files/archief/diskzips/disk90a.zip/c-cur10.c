/************************************************/
/* File  : c-cur10.c                            */
/* Auteur: Alex Wulms                           */
/* Gebruik van de XelaSoft bibliotheek          */
/************************************************/
#include <stdio.h>
#include <xslib.h>

/************************************************/
/* Een macro die de calla() functie gebruikt om */
/* een slot uit te lezen                        */
/************************************************/
#define rdslt(slt,addr) \
    calla(0x0c, (int)slt, (int)addr)

/************************************************/
/* Een globale variabele voor het VDP i/o addr  */
/************************************************/
char vdpaddr;

/************************************************/
/* De hoofdfunctie                              */
/************************************************/
int main(argc, argv)
int argc;
char *argv[];
{
  int cnt, n;
  int center;

  /* Lees VDP i/o addr uit de BIOS */
  vdpaddr = rdslt(*((char *)0xfcc1), 6);

  /* Teken een aantal lijnen op scherm 8 */
  screen(8);
  n = atoi(argv[1]);
  center = (256-n)>>1;
  for (cnt = 0; cnt != n; cnt++) {
    atrbyt = center+cnt;
    line(center+cnt,0,  center+n-1-cnt,211);
  }

  /* Wacht op een toetsdruk en klaar */
  getchar();
  screen(0);
  return 0;
}
