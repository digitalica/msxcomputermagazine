source: scc_samp.asm

;******************************
;*** SCC SAMPLER            ***
;***        1997 Cybernetic ***
;******************************
 
        ORG   &HD000
        DI
 
;--- scc init
 
        IN    A,(&HA8)        ; bewaar instelling  
        PUSH  AF
        LD    A,&B11101100    ; cartridge in slot 2
        OUT   (&HA8),A
        LD    A,&H3F          ; schakel SCC in  
        LD    (&H9000),A
        LD    A,15            ; volume 15  
        LD    (&H988A),A
        LD    A,1             ; key on  
        LD    (&H988F),A
        LD    A,&B00010000    ; frequentie op max  
        LD    (&H9880),A
        LD    A,0
        LD    (&H9881),A
 
;--- muziekmodule init
        LD    A,24
        OUT   (&HC0),A
        LD    A,8
        OUT   (&HC1),A
 
        LD    A,25            ; sound module uit
        OUT   (&HC0),A
        LD    A,&B00000000
        OUT   (&HC1),A
;
        LD    A,13            ; opname freq low
        OUT   (&HC0),A
        LD    A,&HE1
        OUT   (&HC1),A
        LD    A,14            ; opname freq high
        OUT   (&HC0),A
        LD    A,0
        OUT   (&HC1),A
        LD    A,8             ; start sampling   
        OUT   (&HC0),A
        LD    A,8
        OUT   (&HC1),A
 
;--- main program
 
        LD    A,&H1A          ; select transport register
        OUT   (&HC0),A
        LD    HL,&HFFFF
        LD    (STACK),SP      ; bewaar stack
 
LOOP:
        LD    SP,&H9820
        IN    A,(&HC1)
        LD    B,A
        LD    C,A
 
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
        PUSH  BC
 
 
        DEC   HL
        LD    A,L
        OR    H
        JP    NZ,LOOP
;
EINDE:
        LD    SP,(STACK)      ; herstel stack
 
        POP   AF              ; herstel page instelling
        OUT   (&HA8),A
        EI
        CALL  &HC0            ; beep
        RET
 
STACK:  DEFW  0               ; oude stackpointer

??



 

 

