source: chngsect.asm

;=========================================================================
;= Dit programma zorgt ervoor dat een schijfje met MSXDOS.SYS            =
;= en COMMAND.COM toch naar BASIC gaat. Met poke &HF346,1:_SYSTEM        =
;= kan weer naar DOS gegaan worden                                       =
;=                                                                       =
;= Gemaakt door Boi Sletterink                                           =
;= Gepubliceerd in MCCM TechnoTalk                                       =
;=========================================================================
 
         org &H8000
SS:
         EX    DE,HL
         CP    &H90
         LD    D,E
         LD    C,(HL)
         LD    E,C
         LD    C,D
         LD    E,B
         LD    (&H3530),A
         NOP
         LD    (BC),A
         LD    (BC),A
         LD    BC,&H0200
         LD    (HL),B
         NOP
         AND   B
         DEC   B
         LD    SP,HL
         INC   BC
         NOP
         ADD   HL,BC
         NOP
         LD    (BC),A
         NOP
         NOP
         NOP
         RET   NC
         LD    (&HC059),DE
         JP    &HC0D0
         LD    (HL),&H56
         INC   HL
         LD    (HL),&HC0
         LD    SP,&HF51F
         LD    DE,&HC0AB
         LD    C,&H0F
         CALL  &HF37D
         INC   A
         JP    Z,&HC063
         LD    DE,&H0100
         LD    C,&H1A
         CALL  &HF37D
         LD    HL,&H01
         LD    (&HC0B9),HL
         LD    HL,&H3F00
         LD    DE,&HC0AB
         LD    C,&H27
         CALL  &HF37D
         JP    &H0100
         LD    E,B
         RET   NZ
         CALL  &H00
         LD    A,C
         AND   &HFE
         CP    &H02
         JP    NZ,&HC06A
         LD    A,(&HC0D0)
         AND   A
         JP    Z,&H4022
         LD    DE,&HC085
         CALL  &HC077
         LD    C,&H07
         CALL  &HF37D
         JR    &H802B
         LD    A,(DE)
         OR    A
         RET   Z
         PUSH  DE
         LD    E,A
         LD    C,&H06
         CALL  &HF37D
         POP   DE
         INC   DE
         JR    &H8077
         LD    H,L
         LD    (HL),D
         LD    (HL),D
         LD    L,A
         LD    (HL),D
         JR    NZ,&H80AC
         JR    NZ,&H80AE
         JR    NZ,&H809D
         LD    A,(BC)
         LD    B,H
         LD    C,A
         LD    C,(HL)
         DAA
         LD    D,H
         JR    NZ,&H80EF
         LD    C,A
         LD    D,D
         LD    D,D
         LD    E,C
         JR    NZ,&H80E0
         LD    B,L
         JR    NZ,&H80E9
         LD    B,C
         LD    D,B
         LD    D,B
         LD    E,C
         JR    NZ,&H80C7
         JR    NZ,&H80B6
         LD    A,(BC)
         NOP
         NOP
         LD    C,L
         LD    D,E
         LD    E,B
         LD    B,H
         LD    C,A
         LD    D,E
         JR    NZ,&H80D4
         LD    D,E
         LD    E,C
         LD    D,E
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         NOP
         AND   A
         JP    Z,&H4022
         LD    (&HC0D0),A
         JP    &HC026
 
EE:
??



 

 

