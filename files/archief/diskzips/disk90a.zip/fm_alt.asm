source: fm_alt.asm

        ORG   &H9000
 
WRSLT:  EQU   &H14            ;WRite SLot
 
FM_REG: EQU   &H7C            ;FM-pac REGister i/o port
FMDATA: EQU   &H7D            ;FM-pac DATA i/o port
 
 
; FM-PAC access test
; IN     : E = selection: &HFF = direct FM-PAC access using normal I/O ports
;                         else: slot-ID where FM-PAC can alternatively be
;                               accessed at:
;                               MSb   7   6   5   4   3   2   1   0   LSb
;                                   +---+---+---+---+---+---+---+---+
;                                   |EXP| 0 | 0 | 0 |SS1|SS0|PS1|PS0|
;                                   +---+---+---+---+---+---+---+---+
;                               with: PS1-PS0 = Primary   Slot # (0 .. 3)
;                                     SS1-SS0 = Secundary Slot # (0 .. 3)
;                                               (if expanded)
;                                     EXP     = secundary slot EXPanded boolean:
;                                               0 = not expanded, 1 = expanded
; PRECON : - FM-PAC has been activated.
; OUT    : -
; POSTCON: - (maskable interrupts might be disabled (DI))
; USES   : A,B,C,F,H,L
; CALLS  : FM_OUT, FMMOUT
 
FMTEST: ;FM-pac TEST
        LD    HL,DATA
 
LOOP:   LD    A,(HL)          ;fetch register#
        AND   A               ;(end of data marker?)
        RET   Z
        LD    B,A
        INC   HL
        LD    C,(HL)          ;fetch data byte
        INC   HL
 
        BIT   6,E             ;select how to access FM-PAC
        JR    Z,JUMP
 
        CALL  FM_OUT          ;access FM-PAC using normal I/O ports
        JR    LOOP
 
JUMP:   LD    A,E             ;access FM-PAC using I/O mapped I/O
        CALL  FMMOUT
        JR    LOOP
 
; Some FM-PAC register settings:
DATA:   DB    &H10,128        ;low-byte frequency
        DB    &H30,&B00010000 ;instrument# and loudest volume
        DB    &H20,&B00000101 ;key-off, octave, and high bit of frequency
        DB    &H20,&B00010101 ;same but now with key-on
        DB    0               ;end of data marker
 
 
; Output data to FM-PAC using I/O ports
; IN     : B = register #
;          C = data byte
; PRECON : -
; OUT    : -
; POSTCON: - data byte has been put into the indicated FM-PAC register.
; USES   : A
; CALLS  : WAIT
 
FM_OUT: ;output value to FM-PAC using I/O ports
        LD    A,B             ;output register#
        OUT   (FM_REG),A
        CALL  WAIT            ;wait for a moment...
        LD    A,C             ;output data byte
        OUT   (FMDATA),A      ;wait for a moment...
        CALL  WAIT
        RET
 
 
; Wait 80 T-States
; IN     : -
; PRECON : -
; OUT    : -
; POSTCON: - waited for atleast 80 T-States.
; USES   : -
; CALLS  : -
 
WAIT:   ;WAIT a moment
        EX    (SP),HL
        EX    (SP),HL
        EX    (SP),HL
        EX    (SP),HL
        RET
 
 
; Output data to FM-PAC using I/O Mapped I/O
; IN     : B = register #
;          C = data byte
;          A = slot ID where FM-PAC can be accessed at.
; PRECON : -
; OUT    : -
; POSTCON: - data has been put in the indicated FM-PAC register.
;          - maskable interrupts are disabled! (DI)
; USES   : -
; CALLS  : WRSLT
 
FMMOUT: ;output value to FM-PAC using memory
        PUSH  AF              ;save used registers
        PUSH  BC
        PUSH  DE
        PUSH  HL
 
        LD    HL,&H7FF4       ;output register#
        PUSH  AF              ;save slot ID
        PUSH  BC              ;save data byte
        LD    E,B
        CALL  WRSLT           ;(this call will generate enough delay by itself)
 
        LD    HL,&H7FF5       ;output data byte
        POP   DE              ;retrieve data byte in register E
        POP   AF              ;retrieve slot ID
        CALL  WRSLT           ;(this call will generate enough delay by itself)
 
        POP   HL              ;retrieve used registers
        POP   DE
        POP   BC
        POP   AF
        RET

??



 

 

