/************************************************/
/* File : c-cur6.c                              */
/* Auteur: Alex Wulms                           */
/* Complexere macro's, de for-loop en machine-  */
/* taal gebruiken via een array en een functie- */
/* pointer typecast                             */
/************************************************/
#include <stdio.h>

/* Definieer een aantal macro's */
#define BUFSIZE 16384
#ifndef MIN
#define MIN(a,b) (a) (b) ? (a) : (b)
#endif

/* Definieer het functie-pointertype */
typedef unsigned (* UnsignedFp)();

/************************************************/
/* Roep een MSX1 BIOS functie aan               */
/************************************************/
unsigned msx1bios(addr, af, hl, de, bc, ret_type)
unsigned af;
unsigned hl, de, bc;
unsigned addr;
char ret_type;
{
 unsigned tmp; /* Buffer voor het resultaat */

 static char ml[34] = { 0x21,0,0, 0xe5,0xf1,
 0x21,0,0, 0x11,0,0, 0x01,0,0, 0xdd,0x21,0,0,
 0xfd,0x2a,0xc0,0xfc, 0xcd,0x1c,0, 0,0,
 0x21,0,0, 0x73,0x23,0x72,0xc9
 }; /* Een ML functie voor de interslot call */

 /* Stop alle registers in de functie */
 *(unsigned *)(ml+1) = af;
 *(unsigned *)(ml+6) = hl;
 *(unsigned *)(ml+9) = de;
 *(unsigned *)(ml+12) = bc;
 *(unsigned *)(ml+16) = addr;

 /* Zet het buffer adres in de functie */
 *(unsigned **)(ml+28) = &tmp;

 /* Gebruik de goede kode om HL of AF terug te geven */
 if (ret_type == 0) {
 ml[25] = 0xeb; ml[26] = 0; /* HL teruggeven */
 }
 else {
 ml[25] = 0xf5; ml[26] = 0xd1; /* AF teruggeven */
 }

 /* Roep de functie aan door het array te beschouwen */
 /* als een functie-pointer        */
 (*(UnsignedFp)ml)();

 return tmp; /* Geef de waarde in de buffer terug */
}

/************************************************/
/* Kopieer data van ram naar vram               */
/************************************************/

VOID ramvrm(addr, aantal)
char *addr;
unsigned aantal;
{
 static char ml[16] = { 0x21,0,0, 0x01,0,0,
 0x7e, 0x23, 0xd3,0x98, 0x0b, 0x78, 0xb1,
 0x20,0xf7, 0xc9 }; /* Een data-kopieerlus */

 /* Zet adres en aantal in de machinecode */
 *(char **)(ml+1) = addr;
 *(unsigned *)(ml+4) = aantal;

 (*(UnsignedFp)ml)(); /* roep de kopieerlus aan */
}

/************************************************/
/* De hoofdfunctie                              */
/************************************************/
int main()
{
 char buffer[BUFSIZE]; /* In/out buffer */
 FD fd;      /* In/out file descriptor */
 struct { char type;
   unsigned begin, eind, strt;
  } header;   /* Bload file header */
 unsigned tel;   /* Lusteller */
 unsigned bufsize;   /* Daadwerkelijke buffergrootte */

 /* Vraag om naam en open het bestand */
 printf("Hoe heet het scherm 8 plaatje? ");
 scanf("%s", buffer);

 fd = open(buffer, O_RDONLY);
 if (fd == ERROR) {
  printf("Openen van het bestand is mislukt\n");
  exit(1);
 }

 /* Lees de header in en controleer het type veld */
 if (read(fd, &header, 7) != 7 || header.type != 0xfe) {
  printf("Het bestand is geen scherm 8 plaatje\n");
  close(fd);
  exit(1);
 }

 /* Pak scherm 8 en stel de vdp in op het goede adres */
 msx1bios(0x5f, 0x0800, 0,0,0 ,0);
 msx1bios(0x171, 0, header.begin,0,0, 0);

 /* Lees het plaatje in via de in/out buffer */
 for (tel = header.eind+1-header.begin; tel != 0;
   tel -= bufsize) {
 bufsize = read(fd, buffer, MIN(tel, BUFSIZE));
  if (bufsize != 0)
  ramvrm(buffer, bufsize);
  else
  tel = 0; /* Het bestand is te vroeg op */
 }
 close(fd);

 /* Wacht op een toets en herstel scherm 0 */
 msx1bios(0x9f, 0, 0,0,0, 0);
 msx1bios(0x6c, 0, 0,0,0, 0);
}
