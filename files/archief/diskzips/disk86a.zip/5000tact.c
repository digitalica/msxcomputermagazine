/* file: 5000tact.c 
 * door: Arnold Metselaar
 * 
 * programma voor het 5000-spel (zie MCCM 83)
 * beslissende functies voor automatisch spelen
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "5000spel.h"

/* in deze file : */
FAST doorgaan(char*,char*,char*,UFAST,UFAST,UFAST);
char extra_gok(char);
uint ber_sc(char*, char*, UFAST, UFAST, UFAST);
FAST sub_str(char*, char*, FAST);

extern uint RestB[WINLIM];

  /* bepaal welke stenen uitgelegd  moeten  worden  en  of  daarna  nog
gegooid moet worden */
FAST doorgaan(char * bak, char * worp, char * zet_uit, 
	      UFAST totsc, UFAST brtsc, UFAST vb)
{
  FAST i, lenw;
  FAST wrdb, wrdn;
  uint bstsc, nwsc;
  FAST vl, uitw;
  char nuit[7];
                      
  zet_uit[0]='\0';
  uitw=WINLIM-totsc-brtsc;
  if (brtsc+uitw<SCHRLIM) uitw=SCHRLIM-brtsc;
  /* uitw is genoeg om te winnen */
  vl=3; lenw=strlen(worp);
  for (i=(1<<lenw)-1 ; i && vl ; i--)
  {
    if (sub_str(worp,nuit,i) && ((wrdn=waarde(nuit,bak)) >=0))
    {
      if (wrdn>=uitw) vl=0;
      switch(vl)
      {
	case 3: wrdb=wrdn;
		strcpy(zet_uit,nuit);
		vl=2;
		break;
        case 2:	bstsc=ber_sc(bak,zet_uit,totsc,brtsc+wrdb,vb);
		if (klepnivo>=3) 
		  printf("\n+ %s = %d -> %u\n",zet_uit,SC*wrdb,bstsc);
		vl=1;
	case 1:	nwsc=ber_sc(bak,nuit,totsc,brtsc+wrdn,vb);
		if (klepnivo>=3) printf("+ %s = %d -> %u\n",nuit,SC*wrdn,nwsc);
                if (bstsc<=nwsc) break;
		bstsc=nwsc; 
		wrdb=wrdn; 
	case 0: strcpy(zet_uit,nuit);
      }
    }
  }

  if ((vl==3)||(vl==0)) return 0; /* mislukt of gewonnen */
  if ((brtsc+wrdb<SCHRLIM)||(wrdb==0)||     /* te weinig of sextet nodig of */
      ((strlen(zet_uit)==lenw)&&(vb<BAKLIM))) return 1;/* volle bak bewijzen */

  if (vl==2) bstsc=ber_sc(bak,zet_uit,totsc,brtsc+wrdb,vb);
  return (bstsc<RestB[totsc+brtsc+wrdb]);
}

  /* bepaal de extra gok */
char extra_gok (char x)
{ 
  return '3'+(x&1) ;
}

  /* zet substring met code index in *deel, geef 0  terug  als  er  een
kleinere index die, modulo permutaties, dezelfde deelstring  geeft,  is
*/
FAST sub_str(char *geheel, char *deel, FAST index)
{
  int j;
  char *z;
  char skipped[7];

  z=skipped;
  *z='\0';
  for ( j=1 ; j && (j<=index) ; j<<=1, geheel++)
  {
    if (j&index)
    { 
      *deel++=*geheel; 
      if (strchr(skipped,*geheel)) j=0; 
    }
    else 
    { 
      *z++=*geheel;
      *z='\0';
    }
  }
  *deel='\0';
  return j;
}

/* bereken de score van een uitzetsel */
uint ber_sc(char *bak, char *uit,UFAST totsc,UFAST brtsc,UFAST vb)
{
  char n_bak[7];

  return verw_beurt(strcat(strcpy(n_bak,bak),uit), 
		    (totsc>(WINLIM-SCHRLIM)) ? WINLIM-SCHRLIM : totsc,
		    brtsc, vb);
}

