        ORG   &HD000

; S      = start
; SELECT = select
; B, A, X, Y, L, R = GELIJK
; CURSOR = RICHTING

BB:
        CALL  SCAN
        LD    A,H
        CALL  PRIDAT
        LD    A,L
        CALL  PRIDAT
        LD    (DATA),HL
        RET

DATA:   DEFW  0

; === Scan key-board ===
; OUPUT: H = #1 BYTE FOR OUTPUT
;        L = #2 BYTE FOR OUTPUT

SCAN:   ;SCAN key-board
        LD    HL,&HFFF3       ;reset first

        LD    A,(&HFBEC)      ;scan 'SELECT'
        ADD   A,A             ;skip
        ADD   A,A
        RL    H               ;out: H = 1111111E

        LD    A,(&HFBEA)      ;scan 'S'
        SRL   A
        RL    H               ;out: H = 111111ES

        LD    A,(&HFBED)      ;scan cursor
        ADD   A,A
        LD    B,A
        RL    H
SLA   B
        SLA   B
        SLA   B
        RL    H
        ADD   A,A
        RL    H
        ADD   A,A
        RL    H               ;out: H = 11ESRLDU

        LD    A,(&HFBE7)
        ADD   A,A
        RL    H               ;out: H = 1ESRLDUB

        LD    A,(&HFBEA)      ;scan 'X'
        ADD   A,A             ;skip 2 bits
        ADD   A,A
        ADD   A,A
        RL    L               ;out: L = 1111011X

        LD    A,(&HFBE9)      ;scan 'L'
        SRL   A               ;skip 1 bit
        SRL   A
        RL    L               ;out: L = 111011XL

        LD    A,(&HFBE9)      ;scan 'R'
        ADD   A,A
        RL    L               ;out: L = 11011XLR

        LD    A,(&HFBE7)      ;scan 'A'
        ADD   A,A             ;skip 1 bit
        ADD   A,A
        RL    L               ;out: L = 1011XLRA

        LD    A,(&HFBEA)      ;scan 'Y'
        ADD   A,A             ;skip 1 bit
        ADD   A,A
        RL    L               ;out: L = 011XLRAY

        RET
;===== PRInt DATa =======
PRIDAT:
        OUT   (&H91),A        ;output data
        XOR   A
        OUT   (&H90),A        ;strobe signal enable  (0)
        LD    A,1
        OUT   (&H90),A        ;strobe signal disable (1)

        RET
EE:

