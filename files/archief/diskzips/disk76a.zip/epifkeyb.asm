BEGIN   8000 DB 08       IN   A,(08)     lees status-register "EPIFIET"
        8002 A7          AND  A          geldige data aanwezig?
        8003 20 22       JR   NZ,22 8027 nee, dan naar OHKEYI

        8005 2A F8 F3    LD   HL,(F3F8)  lees *>PUTPNT<*
        8008 54          LD   D,H  ----| bewaar *>PUTPNT<*
        8009 5D          LD   E,L  ----|
                         ----------------ga naar volgende plaats in *>KEYBUF<*
        800A 23          INC  HL         verhoog met 1
        800B 7D          LD   A,L
        800C FE 18       CP   18         boven hoogste adres van *>KEYBUF<* ?
        800E 20 03       JR   NZ,03 8013 nee, ga naar BUFVOL
        8010 21 F0 FB    LD   HL,FBF0    ja,dan begin *>KEYBUF<*
                         ----------------is de buffer vol?
BUFVOL  8013 3A FA F3    LD   A,(F3FA)   lees *>GETPNT<*
        8016 BD          CP   L
        8017 28 0E       JR   Z,0E 8027  als buffer vol, ga dan naar OHKEYI

        8019 DB 09       IN   A,(09)     lees data-register "EPIFIET"
        801B FE 0A       CP   0A         is dit een LineFeed?
        801D 28 08       JR   Z,08 8027  ja, dan negeer dit en ga naar OHKEYI
        801F 00          NOP - - - - - -
        8020 00          NOP            |reserve ruimte voor nog
        8021 00          NOP            |een test en negeer
        8022 00          NOP - - - - - -
        8023 12          LD   (DE),A     zet data in *>KEYBUF<*
        8024 22 F8 F3    LD   (F3F8),HL  geef *>PUTPNT<* nieuwe waarde

OHKEYI  8027 C9          RET - - - - - - op deze plaats komt tijdens het
        8028 C9          RET            |installeren van dit programma de
        8029 C9          RET            |originele inhoud van de hook
        802A C9          RET            |  *>HKEYI<*  te staan
        802B C9          RET - - - - - -
        802C C9          RET             einde "EPIFKEYB" programma
        ----             ----------------installatie programma
START   802D 21 9A FD    LD   HL,FD9A    bron-*>HKEYI<*
        8030 11 27 80    LD   DE,8027    doel-OHKEYI
        8033 01 05 00    LD   BC,0005    aantal byte = 5
        8036 ED B0       LDIR            copyeer blok
        8038 21 46 80    LD   HL,8046    bron-NHKEYI
        803B 11 9A FD    LD   DE,FD9A    doel-*>HKEYI<*
        803E 01 05 00    LD   BC,0005    aantal byte = 5
        8041 F3          DI              zet interrupt uit
        8042 ED B0       LDIR            copyeer blok
        8044 FB          EI              zet interrupt aan
        8045 C9          RET             einde installatie programma

NHKEYI  8046 CD 00 80    CALL 8000 - - - de hook *>HKEYI<* krijgt
        8049 C9          RET            |dit als nieuwe inhoud
        804A C9          RET - - - - - -
