root      ld a,1
          ld de,0
          ld hl,0
rootLoop  sla c
          rl b
          rl l
          rl h
          sla c
          rl b
          rl l
          rl h
          scf
          rl e
          rl d
          sbc hl,de
          jr nc,shiftOne
shiftZero add hl,de
          dec de
          sla a
          jr nc,rootLoop
          ret
shiftOne  inc de
          scf
          rl a
          jr nc,rootLoop
          ret
