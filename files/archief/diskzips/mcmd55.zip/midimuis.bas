10 REM MIDIMUIS
20 REM
30 REM Controllers besturen met de muis
40 REM
50 REM MSX Computer Magazine
60 REM
70 SCREEN 0: CLS: WIDTH 80: KEY OFF: DEFINT A-Z
80 PRINT "MIDIMUIS"
90 PRINT "--------": PRINT
100 PRINT "MIDI-controllers besturen met een muis"
110 PRINT "Deze versie werkt alleen in combinatie met de Music Module!"
120 PRINT "Het aanpassen voor FAC MIDI Interface laten we aan de gebruiker over.": PRINT
130 PRINT "Door de muis heen en weer te bewegen kan de stereobalans (controller 10) van hetingestelde kanaal gewijzigd worden.
140 PRINT "Naar boven en beneden resulteert in een modulatieverandering (controller 1).
150 PRINT "De controllersnummers staan in de regels 260 en 270.": PRINT
160 OUT 0,3: OUT 0,21
170 PRINT "MIDI-Kanaal (1-16)";: INPUT I
180 C=&HB0+I-1
190 OUT 1,C: OUT 1,&H63: OUT 1,1
200 OUT 1,C: OUT 1,&H62: OUT 1,32
210 X=64:Y=64
220 IF NOT PAD(12) THEN 220
230 X=X+(PAD(13)/2): Y=Y+(PAD(14)/2)
240 IF X>127 THEN X=127 ELSE IF X<0 THEN X=0
250 IF Y>127 THEN Y=127 ELSE IF Y<0 THEN Y=0
260 OUT 1,C: OUT 1,10 : OUT 1,X
270 OUT 1,C: OUT 1,1: OUT 1,Y
280 GOTO 220
