;RDMOUS: Leest muis uit in poort 1 (of poort 2)
;
;Mous_x: X-as muis
;Mous_y: Y-as muis
;Msbut1: Vuurknop 1 muis (links)
;Msbut2: Vuurknop 2 muis (rechts)
;
;Gebruikt AF, HL
;
RDMOUS: DI                    ;Geen lastige interrupts.
        LD    A,%10010011     ;%11101100 voor muispoort 2
        LD    H,A
        LD    B,30            ;Ietsje langer wachten
        CALL  RMOUS1          ;Laad Hi-nibble X in A
        AND   #0F
        RLCA                  ;Maak van Lo naar Hi
        RLCA
        RLCA
        RLCA
        LD    L,A             ;Bewaar A in L
        CALL  RMOUSE          ;Laad Lo-nibble X in A
        AND   #0F
        OR    L               ;Tel Lo-nibble op bij Hi-nibble
        LD    L,A             ;Bewaar A in L
        LD    A,(MOUS_X)      ;Laad A met huidige X-as muis
        SUB   L               ;Trek verschuiving van A af
        LD    (MOUS_X),A      ;En bewaar de nieuwe X-as
        CALL  RMOUSE          ;Laad Hi-nibble Y in A
        AND   #0F
        RLCA                  ;Maak van Lo naar Hi
        RLCA
        RLCA
        RLCA
        LD    L,A             ;Bewaar A in L
        CALL  RMOUSE          ;Laad Lo-nibble Y in A
        AND   #0F
        OR    L               ;Tel Lo-nibble bij Hi-nibble op
        LD    L,A             ;Bewaar A in L
        LD    A,(MOUS_Y)      ;Laad A met huidige Y-as muis
        SUB   L               ;Trek verschuiving van A af
        LD    (MOUS_Y),A      ;En bewaar de nieuwe Y-as
;
        IN    A,(#A2)         ;Lees vuurknoppen in
        AND   %00010000       ;Test op vuurknop 1
        LD    A,0             ;Als niet ingedrukt dan A=0
        JP    NZ,RDMS03
        DEC   A               ;Als ingedrukt dan A=255
RDMS03: LD    (MSBUT1),A      ;Bewaar status vuurknop 1
        IN    A,(#A2)         ;Lees vuurknoppen in
        AND   %00100000       ;Test op vuurknop 2
        LD    A,0             ;Als niet ingedrukt dan A=0
        JP    NZ,RDMS04
        DEC   A               ;Als Ingedrukt dan A=255
RDMS04: LD    (MSBUT2),A      ;Bewaar status vuurknop 2
        EI                    ;Interrupts weer aan
        RET

RMOUSE: LD    B,10            ;Wachttijd: 10
RMOUS1: LD    A,15            ;Schrijf PSG-register 15
        DI
        OUT   (#A0),A
        LD    A,H             ;Geef muis signaaltje voor klaarzetten nibble
        EI
        OUT   (#A1),A
        XOR   %00010000       ;%00100000 voor muispoort 2
        LD    H,A
MOUSEW: DJNZ  MOUSEW          ;Wacht B
        LD    A,14            ;Lees PSG-register 14
        DI
        OUT   (#A0),A
        EI
        IN    A,(#A2)         ;Data muis in Lo-nibble van A.
        RET

;Data's
;
MOUS_X: DW    127             ;Begint op midden scherm
MOUS_Y: DW    105
MSBUT1: DB    0
MSBUT2: DB    0
