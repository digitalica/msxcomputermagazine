basic autoexec.bas
