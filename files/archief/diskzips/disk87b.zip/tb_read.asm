;GETTB: Lees het toetsenbord in en zet het in een tabel
;tbtab: Ingelezen tabel van het toetsenbord
;
;Verandert: AF, BC, HL
;
GETTB:  LD    B,0             ;Reset B om tot 11 te tellen
        LD    HL,TBTAB        ;Start tabel in HL
GETTB1: DI                    ;Interrupts uit, ivm BIOS int.
        IN    A,(#AA)         ;Laad waarde PPI poort C in A
        AND   #F0             ;Wis laagste 4 bits (nibble)
        OR    B               ;Zet waarde B in Lo-nibble
        OUT   (#AA),A         ;Geef nieuwe waarde aan PPI
        EI                    ;Na volgende IN int's weer aan
        IN    A,(#A9)         ;Haal waarde rij op
        LD    (HL),A          ;En bewaar in de tabel
        INC   HL              ;Ga naar het volgende adres
        INC   B               ;Verhoog B met 1
        CP    11              ;Test of 11
        JP    C,GETTB1        ;Als nog niet, dan herhaal
        RET                   ;Klaar!


;RDR_TB: Lees rij van toetsenbord
;In: C=te lezen rij
;Uit: A=Gelezen rij
;
RDR_TB: DI                    ;Int's uit, ivm BIOS interrupt
        IN     A,(#AA)        ;Zet waarde C in Lo-nibble
        AND   #F0             ;van PPI-poort C
        OR    C               ;
        OUT   (#AA),A         ;
        EI                    ;Int's weer aan na IN-instr.
        IN    A,(#A9)         ;Laad de rij in A
        RET                   ;Klaar!
