        ORG   #C000

; deel32.asm

; in: (HL) adres noemer
; in: (DE) adres teller

; uit: quotient in (noemer)
; uit; rest in (teller)

; alles 32-bits

GO:     LD    HL,NOEMER
        LD    DE,TELLER

; bewaar registers

DIV32:

        PUSH  BC
        PUSH  HL
        PUSH  DE

; zet tekens op positief

        LD    A,+1
        LD    (TEKENQ),A
        LD    (TEKENR),A

; deeltal naar buffer

        LD    DE,DTALBF
        LD    BC,4
        LDIR

; Is deeltal negatief dan
; teken en deeltal aanpassen

        DEC   HL
        LD    A,#7F
        CP    (HL)
        JP    NC,DELER
        LD    A,(TEKENQ)
        NEG
        LD    (TEKENQ),A
        LD    (TEKENR),A
        LD    HL,DTALBF
        CALL  NEGATE

; deler naar buffer brengen

DELER:  POP   HL
        PUSH  HL
        LD    DE,DLRBF
        LD    BC,4
        LDIR

; teken en deler aanpassen

        DEC   HL
        LD    A,#7F
        CP    (HL)
        JP    NC,DELING
        LD    A,(TEKENQ)
        NEG
        LD    (TEKENQ),A
        LD    HL,DLRBF
        CALL  NEGATE

DELING:

; deeltal in BC' (hoog) en IY (laag)
; deler  in  DE  (hoog) en DE' (laag)
; rest in HL (hoog) en HL' (laag) op nul
; zet bit-teller op 32

        LD    IY,(DTALBF)
        LD    DE,(DLRBF+2)
        AND   A
        SBC   HL,HL
        LD    B,32
        EXX
        LD    BC,(DTALBF+2)
        LD    DE,(DLRBF)
        SBC   HL,HL
        EXX

; voer deling uit

DIVLUS:
        EXX
        ADD   IY,IY
        RL    C
        RL    B
        ADC   HL,HL
        EXX
        ADC   HL,HL
        EXX
        SBC   HL,DE
        EXX
        SBC   HL,DE
        INC   IY
        JP    NC,DIVEND
        DEC   IY
        EXX
        ADD   HL,DE
        EXX
        ADC   HL,DE

DIVEND:
        DJNZ  DIVLUS


; quotient in BC' en IY (hoog,laag)
; en rest in HL en HL' (hoog,laag)
; in de buffers

        EXX
        LD    (DTALBF+2),BC
        LD    (DLRBF),HL
        EXX
        LD    (DLRBF+2),HL
        LD    (DTALBF),IY

; kijk in teken of uitkomst
; negatief moet zijn

        LD    HL,DTALBF
        LD    A,(TEKENQ)
        CP    +1
        CALL  NZ,NEGATE
        LD    HL,DLRBF
        LD    A,(TEKENR)
        CP    +1
        CALL  NZ,NEGATE

; breng inhoud van de buffers over
; naar oorspronkelijke
; deler en deeltal

        POP   DE
        PUSH  DE
        LD    HL,DLRBF
        LD    BC,4
        LDIR
        POP   BC
        POP   DE
        PUSH  DE
        PUSH  BC
        LD    HL,DTALBF
        LD    BC,4
        LDIR

; herstel registers

        POP   DE
        POP   HL
        POP   BC
        RET

TEKENQ: DEFB  0
TEKENR: DEFB  0
DTALBF: DEFW  0,0
DLRBF:  DEFW  0,0

NOEMER: DW    12,0
TELLER: DW    2,0

; inverteer teken

NEGATE: AND   A
        LD    B,4
NEGLUS: LD    A,0
        SBC   A,(HL)
        LD    (HL),A
        INC   HL
        DJNZ  NEGLUS
        RET

        END

: L