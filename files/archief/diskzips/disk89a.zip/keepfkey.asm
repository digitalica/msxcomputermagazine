; =================================================================
; === Reset resisant function keys
; === Only works on MSX 2 machines!
; ===

  	org &hc000
p2dest: equ &h4000    		;Page 2 data DESTination address
fnkstr: equ  &hf87f   		;FuNction Key STRings
; setup ram-segment 2
init: 	di     			;disable interrupts
   	in  a,(&hfe)   		;save current ram-segment in page #2
	push af
	ld a,2    		;select ram-segment 2 in page #2
	out  (&hfe),a
	ld  hl,head     	;copy data and reset-resistant code
	ld de,p2dest+&h4000 	;into ram-segment 2
	ld  bc,head-tail
	ldir
	ld hl,fnkstr		;copy current function key settings
	ld de,keybak-head+p2dest+&h4000
	ld  bc,10*16
	ldir
	pop af			;reset page #2 ram setting
	ei     			;enable interrupts again
	ret

; data to move into ram-segment #2
head:
;header data:
	defb "ab"     		;rom-cartridge signature
	defw reskey-head+p2dest	;pointer to code to execute
				;while initing
	defw 0,0,0,0,0,0  	;reset all other address indicators
; actual reset resistant-code: (relocatable!)
reskey: ld hl,keybak-head+p2dest
	ld de,fnkstr
	ld  bc,10*16
	ldir
	ret
; back-up of function keys:
keybak:
tail: