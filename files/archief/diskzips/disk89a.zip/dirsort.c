/************************************************/
/* File  : dirsort.c                            */
/* Auteur: Alex Wulms                           */
/* Gebruik van de functies qsort(), expargs(),  */
/* strcmp() en free()                           */
/************************************************/
#include <stdio.h>
#include <stdlib.h>

#define MAXNAMES 1000

/************************************************/
/* Deze functie wordt aangeroepen door qsort(). */
/* Ze vergelijkt twee strings met elkaar m.b.v. */
/* de strcmp() functie.                         */
/************************************************/
int vergelijk(s1, s2)
char **s1, **s2;
{
  return strcmp(*s1, *s2);
}

/************************************************/
/* Dit is de hoofdfunctie                       */
/************************************************/
int main(argc, argv)
int argc;     /* aantal tokens */
char *argv[]; /* array met de tokens */
{
  int aantal;  /* aantal filenamen */
  int tel;     /* een tellertje */
  char *xargv[MAXNAMES]; /* De geexpandeerde lijst */

  /* Controleer aantal cmdline argumenten */
  if (argc == 1) {
    printf("Gebruik\n");
    printf("%s <naam1> <naam2> ...\n", argv[0]);
    printf("om de namen naam1, naam2, ... alfabetisch te sorteren.\n");
    printf("De namen mogen wildcharts bevatten\n");
    exit(1);
  }

  /* Expandeer de cmdline argumenten */
  aantal = expargs(argc-1, argv+1, MAXNAMES, xargv);
  if (aantal == -1) {
    printf("Te veel namen opgegeven\n");
    exit(2);
  }

  /* Geef status informatie */
  printf("Aantal gevonden namen: %u, aan het sorteren...\n",
         aantal);

  /* Sorteer de lijst van filenamen */
  qsort(xargv, aantal, sizeof(char *), vergelijk);

  /* Druk de lijst af en geef geheugen weer vrij */
  for (tel = 0; tel != aantal; tel++) {
    printf("%s\n", xargv[tel]);
    free(xargv[tel]);
  }

  return 0;
}
