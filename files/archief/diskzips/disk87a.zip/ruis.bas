'afwijking in ruis bij een 8bit sample (sinus)
' (c) 1996 cs/tbl

SCREEN 7, , 0, 1
amp = 64
DO
GOSUB keyask
FOR t = 0 TO 8 * ATN(1) STEP (8 * ATN(1)) / 128
s = SIN(t + f) * amp
PSET (160 + s, y), 15
s = s - INT(s)
s = s * 50
LINE (0, y)-(s, y), 1
y = y + 1
NEXT t
LOCATE 20: PRINT "amp:"; amp
PCOPY 0, 1: CLS
y = 0
f = f + .05
LOOP

keyask:
a$ = INKEY$
IF a$ = CHR$(27) THEN END
IF a$ = "]" THEN amp = amp + 1
IF a$ = "[" THEN amp = amp - 1

RETURN

