'write 44.1 sample to thisk
' (c) Wolf '96

SCREEN 9
OPEN "c:\sound\trackers\boor.raw" FOR OUTPUT AS #1
GOTO delay

zaag:
FOR units = 1 TO 10
FOR t = 0 TO 440
s = 255 / 440 * t
PSET (t, 128), 1
PSET (t, 0), 1
PSET (t, 256), 1
PSET (t, 0 + s), 15
IF s < 0 THEN s = 0
IF s > 255 THEN s = 255
PRINT #1, CHR$(s);
NEXT t
NEXT units
CLOSE #1
END

randomination:

FOR units = 1 TO 20
FOR t = 0 TO 440
s = RND(1) * 255
PSET (t, 128), 1
PSET (t, 0), 1
PSET (t, 256), 1
PSET (t, 0 + s), 15
IF s < 0 THEN s = 0
IF s > 255 THEN s = 255
PRINT #1, CHR$(s);
NEXT t
NEXT units
CLOSE #1
END

pulse:

pw = 40 ' 50% van totaal=block
FOR units = 1 TO 10
FOR t = 0 TO pw
s = 0
PSET (t, 128), 1
PSET (t, 0), 1
PSET (t, 256), 1
PSET (t, 0 + s), 15
IF s < 0 THEN s = 0
IF s > 255 THEN s = 255
PRINT #1, CHR$(s);
NEXT t

FOR t = pw + 1 TO 440
s = 255
PSET (t, 128), 1
PSET (t, 0), 1
PSET (t, 256), 1
PSET (t, 0 + s), 15
IF s < 0 THEN s = 0
IF s > 255 THEN s = 255
PRINT #1, CHR$(s);
NEXT t
NEXT units
CLOSE #1
END


sinus:

FOR units = 1 TO 10
FOR t = 0 TO 440
s = 255 / 440 * t
PSET (t, 128), 1
PSET (t, 0), 1
PSET (t, 256), 1
PSET (t, 0 + s), 15
IF s < 0 THEN s = 0
IF s > 255 THEN s = 255
PRINT #1, CHR$(s);
NEXT t
NEXT units
CLOSE #1

delay:

DIM tx(441) 'texture...
FOR t = 0 TO 441
tx(t) = (255 / 441 * t) 'zaag
NEXT t


delay = 80
FOR t = 0 TO 411 STEP 2
s1 = tx(t)
s2 = tx((t + delay) MOD 441)
s = (s1 + s2) / 2
PSET (t, 128), 1
PSET (t, 0), 1
PSET (t, 256), 1
PSET (t, 0 + s), 15
IF s < 0 THEN s = 0
IF s > 255 THEN s = 255
PRINT #1, CHR$(s);
NEXT t
CLOSE #1
END


