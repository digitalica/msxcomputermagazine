/*========================================================================

  <SIMPEL PONG>

  (c)1992 MSX Computer Magazine

Simpele versie van <Pong> voor MSX-C 1.1 of 1.2. Hij roept de MSX-BIOS aan
zonder gebruik te maken van handmatige machinetaal-programmering. Bij het
linken moet het startadres zich boven 0x4000 (&h4000) bevinden.

Gebruik:
 - Beweeg het batje met joystick of cursortoetsen.
 - Verlaat het spel met <ESC>
 - SIMPEL PONG werkt op alle MSX-computers. De meegeleverde bload-versie
   heeft als beginadres &Hf975 - het programma past ruim in de play-queues -
   dus werkt hij zelfs op 8 KB-machines ! Al moet hij voor 32 KB of minder
   wel eerst op een cassette gezet worden, want voor een diskdrive moet een
   MSX-computer minimaal 64 Kb bezitten.
========================================================================*/
#pragma	nonrec

typedef	char	void;

#define	chgmod		(*(void (*)())0x005f)
#define	ldirvm		(*(void (*)())0x005c)
#define	chgclr		(*(void (*)())0x0062)
#define	calpat		(*(void * (*)())0x0084)
#define	calatr		(*(void * (*)())0x0087)
#define	chput		(*(void (*)())0x00a2)
#define	posit		(*(void (*)())0x00c6)
#define	gtstck		(*(char	(*)())0x00d5)
#define	snsmat		(*(char (*)())0x0141)
#define	FORCLR		(*(char *)0xf3e9)
#define	BAKCLR		(*(char *)0xf3ea)
#define	BDRCLR		(*(char *)0xf3eb)
#define	INTCNT		(*(unsigned *)0xfca2)

typedef	struct
{
	char	YPos;
	char	XPos;
	char	PtrNr;
	char	Color;
}	Sprite;

static	char	RacketPtrn[8] = { 0x00,0x00,0x00,0x00,0x00,0x00,0xff,0xff };
static	Sprite	Racket        = { 180 , 150, 0, 1 };
static	char	BallPtrn[8]   = { 0x3c,0x7e,0xff,0xff,0xff,0xff,0x7e,0x3c };
static	Sprite	Ball          = { 2, 3, 1, 8 };
static	char	DXTable[9]    = { 0, 0, 3, 3, 3, 0,-3,-3,-3 };
static	void	*BallAtr,*RacketAtr;
static	char	Balldx = 3;
static	char	Balldy = 2;
static	char	Score  = 0;

void	Init(),MvBall(),MvRacket(),DspScore();
char	Touched(),abs();

void	main()
{
	unsigned int	oldval;

	chgmod((char)1);
	FORCLR = 1; BAKCLR = 7;	BDRCLR = 2;
	chgclr();
	DspScore();

	while(snsmat((char)7)!=(char)0xfb)
	{
		char	g = gtstck((char)0) | gtstck((char)1);

		if(INTCNT!=oldval)
		{
			oldval = INTCNT;
			MvRacket(DXTable[g]);
			MvBall();
		}
	}
	chgmod((char)0);
}

void	Init()
{
	ldirvm(RacketPtrn,calpat((char)0),8);
	ldirvm(BallPtrn,calpat((char)1),8);
	BallAtr = ( RacketAtr = calatr((char)0) )+sizeof(Sprite);
	Ball.YPos = 2;
}

void	DspScore()
{
	posit(0x0102);
	chput((char)0x30+ Score++); /* verbeteren !! */
	Init();
}

void	MvRacket(dx)
	char	dx;
{
	Racket.XPos+=dx;
	ldirvm(&Racket,RacketAtr,sizeof(Sprite));
}

void	MvBall()
{
	char	*x = &Ball.XPos;
	char	*y = &Ball.YPos;

	if(*y==(char)184)
	{
		DspScore();
		return;
	}
	if(*x==0 || *x==(char)249)	Balldx = -Balldx;
	if(*y==0 || Touched())		Balldy = -Balldy;
	*x += Balldx; *y += Balldy;
	ldirvm(&Ball,BallAtr,sizeof(Sprite));
}

char	Touched()
{
	return	(Racket.YPos==Ball.YPos && abs(Racket.XPos-Ball.XPos)<9);
}

char	abs(q)
	char	q;
{
	if(q&0x80)	return ~q;
		else	return	q;
}
