cf -r7:5:3 game
cg -k game
m80=game/z
l80 /p:f975,game,game/x/n/e:main@
bsave game.hex game.bin
