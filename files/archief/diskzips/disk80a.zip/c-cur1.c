/************************************************/
/* File  : c-cur1.c				*/
/* Auteur: Alex Wulms				*/
/************************************************/
#include <stdio.h>

int main()
{
  printf("MSX forever\n");
}
