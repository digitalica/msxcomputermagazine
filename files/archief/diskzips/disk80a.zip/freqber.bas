10 PRINT
20 INPUT " Welke frequentie" ; HZ
30 FR$ = "'e toonregister is:"
40 KF = 3579545#:
50 N = INT(KF/(32*HZ))
60 FL = INT(N/256)
70 FH = N-FL
80 PRINT
90 PRINT " De waarden zijn:"
100 PRINT
110 PRINT "1";FR$; FH
120 PRINT "2";FR$; FL
