/************************************************/
/* File  : c-cur2.c				*/
/* Auteur: Alex Wulms				*/
/* Een voorbeeld van het gebruik van escape	*/
/* sequences.					*/
/************************************************/
#include <stdio.h>

int main()
{
  printf("Dit is een regel.\nDe \x41 van \"Al\
ex\" heeft ascii code 41 hex.");
}
