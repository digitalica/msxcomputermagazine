100 ' ; TAFEL
110 ' ; Zet de tafel van GETAL op
120 ' ; het scherm.
130 '
140 ' equ GETAL ,$17
150 ' equ EINDE ,$72
160 ' equ CHPUT ,$00A2
170 ' equ MASKER,$0F
180 ' equ IS    ,61     ; ASCII =
190 ' equ KEER  ,120    ; ASCII x
200 ' equ NUL   ,48     ; ASCII 0
210 ' equ CR    ,13     ; car.return
220 ' equ LF    ,10     ; line feed
230 '
240 ' org $C000
250 '
260 ' ; B x C = DE (Alles in BCD)
270 '
280 ' START:    ; Hoofdprogramma
290 '   ld c,GETAL
300 '   ld b,0
310 '   ld de,0
320 ' MLOOP:
330 '   call PRTSOM     ; Druk af
340 '   call NXTSOM     ; Volgende
350 '   ld a,b
360 '   cp EINDE
370 '   jr nz,MLOOP
380 '   ret             ; Basic
390 '
400 ' PRTSOM:   ; Print een som
410 '   ld a,b
420 '   call PRTGET
430 '   ld a,KEER
440 '   call CHPUT
450 '   ld a,c
460 '   call PRTGET
470 '   ld a,IS
480 '   call CHPUT
490 '   ld a,d
500 '   call PRTGET
510 '   ld a,e
520 '   call PRTGET
530 '   ld a,CR
540 '   call CHPUT
550 '   ld a,LF
560 '   call CHPUT
570 '   ret
580 '
590 ' PRTGET:   ; Print een getal
600 '   push af
610 '   rra
620 '   rra
630 '   rra
640 '   rra
650 '   and MASKER
660 '   add a,NUL
670 '   call CHPUT
680 '   pop af
690 '   and MASKER
700 '   add a,NUL
710 '   call CHPUT
720 '   ret
730 '
740 ' NXTSOM:   ; Bereken volgende
750 '   ld a,b
760 '   add a,1
770 '   daa
780 '   ld b,a
790 '   ld a,e
800 '   add a,c
810 '   daa
820 '   ld e,a
830 '   ret nc
840 '   ld a,d
850 '   add a,1
860 '   daa
870 '   ld d,a
880 '   ret
