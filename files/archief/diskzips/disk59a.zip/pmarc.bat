C:
COPY A:COMMAND.COM
COPY A:PMARC2.COM
COPY A:PMSFX2.COM
REM    U kunt beginnen met het maken van een ARCHIEF-FILE.
