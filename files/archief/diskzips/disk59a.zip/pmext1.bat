C:
COPY A:PMEXT.COM
REM    U kunt beginnen met het uitpakken van een .PMA file.
