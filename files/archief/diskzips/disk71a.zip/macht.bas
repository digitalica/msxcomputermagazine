10 ' Door: Joost Damad
20 '       Fabiolalaan 17
30 '       B-2350 Vosselaar
40 '       Belgie
50 '       Tel.: 014/611753
60 '
100 ' macht recursief m.b.v. exprif volgens ABACUS-principe
110 DEFINT A-Z
120 DEF FN N(J)=(J+1):' opvolger-functie
130 DEF FN P(J)=(J-1):' voorganger-functie
140 DEF FN U(J)=(J>0):' test of nul -functie
150 DEF FN S(I,J)={FNU(I)|FNN(FNS(FNP(I),J))|{FNU(J)|FNN(FNS(I,FNP(J)))|0}}
160 DEF FN PR(I,J)={FNU(I)|FNS(J,FNPR(FNP(I),J))|0}
170 DEF FN M(I,J)={FNU(J)|FNPR(I,FNM(I,FNP(J)))|1}
180 INPUT "Geef grondtal>=0 en exponent>=0";A,B
190 PRINT FN M(A,B)
