/************************************************/
/* File  : tee.c                                */
/* Auteur: Alex Wulms                           */
/* High level file i/o functies gebruiken       */
/************************************************/
#include <stdio.h>

int main(argc, argv)
int argc;
char *argv[];
{
  char regel[80];   /* Buffer voor een regel */
  FILE *uitbestand; /* Het uitvoer bestand   */

  /* Controleer aantal paramters */
  if (argc != 2) {
    printf("Use: %s <filename>\n", argv[0]);
    exit(1);
  }

  /* Open uitvoer bestand voor schrijven */
  if ((uitbestand=fopen(argv[1], "w"))==NULL) {
    printf("Error creating %s\n", argv[1]);
    exit(1);
  }

  /* Lees stdin zolang het kan */
  while (gets(regel, 80) != NULL) {
    puts(regel); /* kopieer naar stdout */
    fputs(regel, uitbestand); /* en naar bestand */
  }

  /* Klaar, sluit het uitvoer bestand */
  fclose(uitbestand);

  return 0;
}

