/************************************************/
/* File  : c-cur8.c                             */
/* Auteur: Alex Wulms                           */
/* Command line parameters gebruiken vanuit C   */
/************************************************/
#include <stdio.h>

int main(argc, argv)
int argc;     /* aantal tokens */
char *argv[]; /* array met de tokens */
{
  int cnt; /* een tellertje */

  printf("argc: %d\n", argc);
  for (cnt = 0; cnt != argc; cnt++)
    printf("argv[%d]: %s\n", cnt, argv[cnt]);
}

