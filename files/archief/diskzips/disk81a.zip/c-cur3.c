/************************************************/
/* File  : c-cur3.c                             */
/* Auteur: Alex Wulms                           */
/* De functies printf() en scanf() gebruiken en */
/* beslissingen nemen met het if statement      */
/************************************************/
#include <stdio.h>

int main()
{
  int getal;   /* Een (16-bits) integer getal */

  printf("Voer een integer getal in: ");
  scanf("%d", &getal);
  if (getal < 0)
    printf("Je voerde een negatief getal in.\n");
  else
    printf("Je voerde een positief getal in.\n");
}

