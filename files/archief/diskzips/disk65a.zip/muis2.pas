PROGRAM MUIS;

CONST uit_aan    : ARRAY [FALSE..TRUE] OF STRING[3] = ('UIT','AAN');
      muis_stick : ARRAY [FALSE..TRUE] OF STRING[5] = ('MUIS ','STICK');
VAR posx,posy   : BYTE;
    muis        : ARRAY [0..1] OF BOOLEAN;
    stickwaarde : ARRAY [0..2] OF BYTE;

FUNCTION Escape : BOOLEAN;
VAR k : CHAR;
BEGIN
  k:=' ';
  IF KEYPRESSED THEN READ(KBD,k);
  Escape:=(k=#27)
END;

FUNCTION Stick(id : BYTE) : BYTE;
BEGIN
  INLINE($3A/id/$FD/$2A/$C0/$FC/$DD/$21/
         $D5/$00/$CD/$1C/$00/$32/id/$FB);
  Stick:=id
END;

FUNCTION Strig(id : BYTE) : BOOLEAN;
BEGIN
  INLINE($3A/id/$FD/$2A/$C0/$FC/$DD/$21/
         $D8/$00/$CD/$1C/$00/$32/id/$FB);
  Strig:=(id<>0)
END;

FUNCTION Knop1 : BOOLEAN;
BEGIN
  Knop1:=Strig(0) OR Strig(1) OR Strig(2)
END;

FUNCTION Knop2 : BOOLEAN;
VAR k : CHAR;
BEGIN
  k:=' ';
  IF KEYPRESSED THEN READ(KBD,k);
  Knop2:=(UPCASE(k)='N') OR Strig(3) OR Strig(4)
END;

FUNCTION Pad(id : BYTE) : BYTE;
VAR a : BYTE;
BEGIN
  INLINE($FD/$2A/$C0/$FC/
    $DD/$21/$DB/$00/ $3A/id/
    $CD/$1C/$00/ $32/id);
  Pad:=id
END;

PROCEDURE Besturing(VAR x,y : BYTE);

CONST plusx : ARRAY [0..8] OF INTEGER = (0,0,1,1,1,0,-1,-1,-1);
      plusy : ARRAY [0..8] OF INTEGER = (0,-1,-1,0,1,1,1,0,-1);
VAR xsave : BYTE ABSOLUTE $FAFE;
    ysave : BYTE ABSOLUTE $FB00;
    mx,my : INTEGER;
    poort : BYTE;

  PROCEDURE nieuw;
  CONST startx : BYTE=0;
        starty : BYTE=0;
        eindx  : BYTE=255;
        eindy  : BYTE=211;
  BEGIN
    x:=x+mx-ORD(((x+mx)<startx) OR ((x+mx)>eindx))*mx;
    y:=y+my-ORD(((y+my)<starty) OR ((y+my)>eindy))*my
  END;

BEGIN
  stickwaarde[0]:=Stick(0);
  IF stickwaarde[0]<>0 THEN
  BEGIN
    mx:=plusx[stickwaarde[0]];
    my:=plusy[stickwaarde[0]];
    nieuw
  END ELSE
  FOR poort:=0 TO 1 DO
  BEGIN
    mx:=Pad(12+poort SHL 2);
    IF xsave<>ysave THEN
    BEGIN
      IF xsave>127 THEN mx:=xsave-256 ELSE mx:=xsave;
      IF ysave>127 THEN my:=ysave-256 ELSE my:=ysave;
      nieuw;
      muis[poort]:=FALSE
    END
    ELSE
    BEGIN
      stickwaarde[1+poort]:=stick(poort+1);
      mx:=plusx[stickwaarde[1+poort]];
      my:=plusy[stickwaarde[1+poort]];
      nieuw;
      muis[poort]:=TRUE
    END
  END
END;

BEGIN
  CLRSCR;
  posx:=100;
  posy:=100;
  WRITELN('Positie cursor (x,y) : ');
  WRITELN;
  WRITELN('Poort 1 :');
  WRITELN('Poort 2 :');
  WRITELN;
  WRITELN('Joystick poort 1 heeft waarde :');
  WRITELN('Joystick poort 2 heeft waarde :');
  WRITELN('Cursor toetsen hebben waarde  :');
  WRITELN;
  WRITELN('Vuurknop poort 1 :    eerste knop :');
  WRITELN('                      tweede knop :');
  WRITELN;
  WRITELN('Vuurknop poort 2 :    eerste knop :');
  WRITELN('                      tweede knop :');
  WRITELN;
  WRITELN('Spatie balk :');
  WRITELN;
  WRITELN('ESCAPE voor einde.');
  REPEAT
    Besturing(posx,posy);
    GOTOXY(24,1); WRITE(posx:4,posy:4);
    GOTOXY(11,3); WRITE(muis_stick[muis[0]]);
    GOTOXY(11,4); WRITE(muis_stick[muis[1]]);
    GOTOXY(33,6); WRITE(stickwaarde[1]);
    GOTOXY(33,7); WRITE(stickwaarde[2]);
    GOTOXY(33,8); WRITE(stickwaarde[0]);
    GOTOXY(37,10);WRITE(uit_aan[Strig(1)]);
    GOTOXY(37,11);WRITE(uit_aan[Strig(3)]);
    GOTOXY(37,13);WRITE(uit_aan[Strig(2)]);
    GOTOXY(37,14);WRITE(uit_aan[Strig(4)]);
    GOTOXY(15,16);WRITE(uit_aan[Strig(0)])
  UNTIL Escape;
  CLRSCR
END.