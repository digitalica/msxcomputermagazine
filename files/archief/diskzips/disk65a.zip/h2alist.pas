{$V-,C-} program home2asc;    {version 2.0}

{Dit programma zet een Home Office 2 tekstfile
 om in een ASCII-file
}

type
string14=string[14];
string20=string[20];
string100=string[100];

var
oud,nieuw:text;
kar1,kar:char;
oudenaam,nieuwenaam:string14;
bkopregel,ekopregel:string20;
uitvullen,foutmelding1,foutmelding2:string100;
spaties,uitv,kode,io:integer;

procedure kop;
begin
  writeln;
  writeln('V-Soft    Home Office 2 -> ASCII v.2.0');
  writeln('--------------------------------------');
end; {kop}

{Nu worden twee files geopend. Er wordt gekeken of
 de file die moet worden omgezet al op schijf staat.
 Zo niet, stopt het programma, net als wanneer de
 aan te maken file juist wel bestaat.
}

procedure openfiles;
begin
  foutmelding1:=' ';
  foutmelding2:=' ';
  io:=0;
  write('Geef naam van de Home Office file:  ');
  readln(oudenaam);
  write('Geef naam van de nieuwe ASCII-file: ');
  readln(nieuwenaam);
  assign(oud,oudenaam);
  {$I-} reset(oud); {$I+}      {open file voor lezen}
  if ioresult=1 then           {oude file niet op disk}
  begin
    io:=1;
    foutmelding1:='Home Office file niet gevonden.';
  end;
  assign(nieuw,nieuwenaam);
  {$I-} reset(nieuw); {$I+}
  if ioresult<>1 then          {nieuwe file bestaat al}
  begin
    io:=2;
    foutmelding2:='ASCII file bestaat al.';
  end;
  if io=0 then
  rewrite(nieuw);              {open file voor schrijven}
end; {openfiles}

{Onderstaande procedure verwijdert de eerste karakters
 van een Home Office file met bepaalde onnodige codes,
 tot een karakter $FF.
}

procedure weghalen;
var dummy:integer;
begin
  while kar<>chr($FF) do
  begin
    read(oud,kar);
  end; {while}
  read(oud,kar);
end; {weghalen}

{Procedure 'tabs' haalt de tabcodes weg. Dit zijn geen
 gewone tabs, maar worden in Home Office alleen gebruikt
 aan de linker kantlijn.
}

procedure tabs;
var dummy:integer;
begin
  kode:=1;
  read(oud,kar);
end; {tabs}

{De procedure 'kop-printercode' verwijdert kopregels en
 printercodes uit de tekst.
}

procedure kop_printercode;
begin
  kode:=1;
  read(oud,kar);
  if kar=chr($54) then         {begin kopregel}
  begin
    read(oud,kar);
    while kar<>chr($54) do
    begin
      read(oud,kar);
    end; {while}               {einde kopregel}
    read(oud,kar);
  end; {if}
end; {kopregel}

{Onderstaande procedure kopieert tekens van 32 tot 127
 naar de ASCII-file.
}

procedure schrijf;
begin
  if uitv=1 then
  begin                        {voor de U-optie}
    if (spaties=0) or ((spaties=1) and (kar<>chr(32))) then
    begin
      if (kar>=chr(32)) and (kar<chr(127)) then
      begin
        write(nieuw,kar);
        kode:=0;
        if kar=chr(32) then spaties:=1 else spaties:=0;
      end; {if}
    end; {if spaties}
  end {if uitv=1}
  else
  begin                        {niet voor de U-optie}
    if (kar>=chr(32)) and (kar<chr(127)) then
    begin
      write(nieuw,kar);
      kode:=0;
    end; {if kar}
  end; {if uitv=0}
end; {schrijf}

{Procedure 'crlf' verandert het karakter 141 in een cr-lf.
}

procedure crlf;
begin
  kode:=1;
  write(nieuw,chr(13)+chr(10));
end; {crlf}

{Onderstaande procedure controleert de tekst op de diverse
 codes en coordineert de bijbehorende procedures.
}

procedure controle;
begin
  spaties:=0;
  while not eof(oud) do
  begin
    kode:=0;
    read(oud,kar);
    if kar=chr(1) then kop_printercode;
    if kar=chr(9) then tabs;
    if kar=chr(141) then crlf;
    if kar>chr(127) then kar:=chr(ord(kar)-128);
    if kode=0 then schrijf;
  end; {while not eof}
end; {controle}

{Hoofdprogramma}

begin
  uitv:=0;
  if paramcount<>0 then
  begin
    uitvullen:=paramstr(1);
    kar1:=copy(uitvullen,1,1);
    if (kar1='U') or (kar1='u') then uitv:=1;
  end; {if paramcount}
  kop;
  openfiles;
  if io=0 then
  begin
    writeln;
    writeln('Even geduld aub...');
    weghalen;
    controle;
  end; {if io}
  if io=1 then writeln(foutmelding1);
  if io=2 then writeln(foutmelding2);
  close(oud);
  close(nieuw);
end.
