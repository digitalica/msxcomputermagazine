
PROGRAM MUIS;

CONST uit_aan : ARRAY[FALSE..TRUE] OF STRING[3] = ('UIT','AAN');
VAR posx,posy : BYTE;

FUNCTION Escape : BOOLEAN;
VAR k : CHAR;
BEGIN
  k:=' ';
  IF KEYPRESSED THEN READ(KBD,k);
  Escape:=(k=#27)
END;

FUNCTION Stick(id : BYTE) : BYTE;
BEGIN
  INLINE($3A/id/$FD/$2A/$C0/$FC/$DD/$21/
         $D5/$00/$CD/$1C/$00/$32/id/$FB);
  Stick:=id
END;

FUNCTION Strig(id : BYTE) : BOOLEAN;
BEGIN
  INLINE($3A/id/$FD/$2A/$C0/$FC/$DD/$21/
         $D8/$00/$CD/$1C/$00/$32/id/$FB);
  Strig:=(id<>0)
END;

FUNCTION Knop1 : BOOLEAN;
BEGIN
  Knop1:=Strig(0) OR Strig(1) OR Strig(2)
END;

FUNCTION Knop2 : BOOLEAN;
VAR k : CHAR;
BEGIN
  k:=' ';
  IF KEYPRESSED THEN READ(KBD,k);
  Knop2:=(UPCASE(k)='N') OR Strig(3) OR Strig(4)
END;

FUNCTION Pad(id : BYTE) : BYTE;
VAR a : BYTE;
BEGIN
  INLINE($FD/$2A/$C0/$FC/
    $DD/$21/$DB/$00/ $3A/id/
    $CD/$1C/$00/ $32/id);
  Pad:=id
END;

PROCEDURE Besturing(VAR x,y : BYTE);

CONST plusx : ARRAY [0..8] OF INTEGER = (0,0,1,1,1,0,-1,-1,-1);
      plusy : ARRAY [0..8] OF INTEGER = (0,-1,-1,0,1,1,1,0,-1);
VAR xsave : BYTE ABSOLUTE $FAFE;
    ysave : BYTE ABSOLUTE $FB00;
    mx,my : INTEGER;
    stok,poort : BYTE;

  PROCEDURE nieuw;
  CONST startx : BYTE=0;
        starty : BYTE=0;
        eindx  : BYTE=255;
        eindy  : BYTE=211;
  BEGIN
    x:=x+mx-ORD(((x+mx)<startx) OR ((x+mx)>eindx))*mx;
    y:=y+my-ORD(((y+my)<starty) OR ((y+my)>eindy))*my
  END;

BEGIN
  stok:=Stick(0);
  IF stok<>0 THEN
  BEGIN
    mx:=plusx[stok];
    my:=plusy[stok];
    nieuw
  END ELSE
  FOR poort:=0 TO 1 DO
  BEGIN
    mx:=Pad(12+poort SHL 2);
    IF xsave<>ysave THEN
    BEGIN
      IF xsave>127 THEN mx:=xsave-256 ELSE mx:=xsave;
      IF ysave>127 THEN my:=ysave-256 ELSE my:=ysave;
      nieuw
    END
    ELSE
    BEGIN
      stok:=stick(poort+1);
      mx:=plusx[stok];
      my:=plusy[stok];
      nieuw
    END
  END
END;

BEGIN
  CLRSCR;
  posx:=100;
  posy:=100;
  WRITELN('positie cursor (x,y) : ');
  WRITELN('vuurknop 1 :');
  WRITELN('vuurknop 2 :');
  WRITELN;
  WRITELN('ESCAPE voor einde.');
  REPEAT
    GOTOXY(24,1);WRITE(posx:4,posy:4);
    GOTOXY(14,2);WRITE(uit_aan[Knop1]);
    GOTOXY(14,3);WRITE(uit_aan[Knop2]);
    Besturing(posx,posy)
  UNTIL Escape;
  CLRSCR
END.


