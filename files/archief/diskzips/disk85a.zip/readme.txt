DIABLOX demo package, should contain the following files:

diademo.com  : bootprog
diablox.sys  : system file
diadisk.sys  : system file
diablox.txt  : short manual
fillout.txt  : fill-out form

in this form it may freely be copied and used!

Please contact me if this is not the case,

Albert Huitsing <a.j.huitsing@cs.utwente.nl>
Drentse Mondenweg 5
7831 JA  Nw. Weerdinge
+31 (0)591 521579

note: These files can't be packed with PMARC because of the
      128 byte blocklength of CP/M !!!
      Please use the original package only !
