ORG   &H9000
;BIOS calls and hook
LDIRMV: EQU   &H59
H_TIMI: EQU   &HFD9F
ACPAGE: EQU   &HFAF6
DPPAGE: EQU   &HFAF5

;VDP input/output ports
PORT1R: EQU   &H99
PORT1W: EQU   &H99
PORT3W: EQU   &H9B

;=== Replayer Initer ===
STARTR: ;START Replayer
;is replayer still active?
        LD    A,(ACTIVE)
        AND   A
        RET   NZ

;copy data into datafield
        LD    BC,64*8+1
        LD    DE,ARDATA
        LD    HL,&H6A07
        CALL  LDIRMV

;set GCOUNT and GPOINT
        LD    A,(ASTEPS)
        AND   A
        RET   Z
        INC   A
        LD    (GCOUNT),A
        LD    HL,R_DATA
        LD    (GPOINT),HL

;use which VDP copy command?
        LD    A,(COPYSW)
        AND   A
        JR    Z,JUMP3
        LD    A,&B11010000
        JR    JUMP4
JUMP3:  LD    A,&B10010000
JUMP4:  LD    (VDPDAT+14),A

;set source page (= active page)
        LD    A,(ACPAGE)
        LD    (VDPDAT+3),A

;set destination page (= display page)
        LD    A,(DPPAGE)
        LD    (VDPDAT+7),A

;reset interrupt delay counter, data group pointer and activate
        LD    A,1
        LD    (DELAYC),A
        LD    (ACTIVE),A

;setup interrupt routine
        DI
        LD    HL,H_TIMI
        LD    DE,O_TIMI
        LD    BC,5
        LDIR
        LD    HL,N_TIMI
        LD    DE,H_TIMI
        LD    C,5
        LDIR
        EI
        RET

RSPEED: DB    0               ;Replayer SPEED (=number of interrupts to delay)
LOOPSW: DB    1               ;LOOPing SWitch 1 = loop
COPYSW: DB    0               ;1 = HMMM
ACTIVE: DB    0               ;replayer ACTIVE, 1 = active

;original hook
O_TIMI: DS    5

;new hook
N_TIMI: JP    RPLAYR
        RET
        RET
;=== Actual Replayer (interrupt routine) ===
RPLAYR: ;RePLAYeR
        DI
;delay another interrupt?
        LD    A,(DELAYC)
        DEC   A
        LD    (DELAYC),A
        JP    NZ,O_TIMI

;at end of replayer data?
        LD    A,(GCOUNT)
        DEC   A
        JR    NZ,JUMP1
        LD    A,(LOOPSW)      ;wrap around?
        AND   A
        JP    Z,SHUTDN
        LD    A,(ASTEPS)
        LD    HL,R_DATA
        JR    JUMP2

JUMP1:  LD    HL,(GPOINT)
JUMP2:  LD    (GCOUNT),A

;set source Y and X
        LD    A,(HL)
        LD    (VDPDAT+2),A
        INC   HL
        LD    A,(HL)
        LD    (VDPDAT+0),A
        INC   HL

;set size Y and X
        LD    A,(HL)
        LD    (VDPDAT+10),A
        INC   HL
        LD    A,(HL)
        LD    (VDPDAT+8),A
        INC   HL

;set destination Y and X
        LD    A,(HL)
        LD    (VDPDAT+6),A
        INC   HL
        LD    A,(HL)
        LD    (VDPDAT+4),A
        INC   HL

;calculate number of interrupts to be delayed
        LD    A,(HL)
        LD    B,A
        LD    A,(RSPEED)
        ADD   A,B
        LD    (DELAYC),A
        INC   HL

;skip dummy byte and save pointer to next data group
        INC   HL
        LD    (GPOINT),HL

;wait until VDP is ready
        LD    A,2
        OUT   (PORT1W),A
        LD    A,15+128
        OUT   (PORT1W),A

LOOP1:  IN    A,(PORT1R)
        RRA
        JR    C,LOOP1
        XOR   A
        OUT   (PORT1W),A
        LD    A,15+128
        OUT   (PORT1W),A

;set VDP registers
        LD    A,32
        OUT   (PORT1W),A
        LD    A,17+128
        OUT   (PORT1W),A
        LD    BC,15*256+PORT3W
        LD    HL,VDPDAT
        OTIR
        JP    O_TIMI

;datafield
DELAYC: DB    0               ;number of interrupts DELAY Counter
GCOUNT: DB    0               ;number of yet-to-be replayed Groups COUNTer
GPOINT: DW    0               ;current Group POINTer
VDPDAT: DB    0,0,0,0         ;source registers
        DB    0,0,0,0         ;destination registers
        DB    0,0,0,0         ;size registers
        DB    0,0
        DB    0               ;command registers

;animation replay data
ARDATA: ;Animation Replayer DATA
ASTEPS: DB    0
R_DATA: DS    64*8

;=== Replayer Terminator ===
SHUTDN: ;SHUT DowN replayer
        XOR   A
        LD    (ACTIVE),A
        LD    HL,O_TIMI
        LD    DE,H_TIMI
        LD    BC,5
        LDIR
        JP    H_TIMI
