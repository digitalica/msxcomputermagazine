; BREAK.ASM
; 1996 NoXoR 
;
ORG   &HF750
;hang de routine aan een hook
        JP    HOOK
;herstel hook
        JP    UNHOOK
HOOK:
        DI
;verplaats wat aan de hook hangt
;naar een buffetje
        DL    HL,H_TIMI
        LD    DE,O_TIMI
        LD    BC,5
        LDIR
;hang eigen routine erbij
        LD    HL,N_TIMI
        LD    DE,H_TIMI
        LD    BC,5
        LDIR
        EI
        RET

UNHOOK:
DI
;verplaats buffer hook weer
;terug naar H_TIMI
        LD    HL,O_TIMI
        LD    DE,H_TIMI
        LD    BC,5
        LDIR
        EI
        RET

;detectie routine START:
        IN    A,(PPI_B)
        AND   &HF0
;rij 6     (Noot1)
        OR    &H06
        OUT   (PPI_B),A
        IN    A,(PPI_A)

;bit0,1,2,4 laag? (Noot3)
CP    &B11101000
;zoniet ga sla routines over
JR    NZ,CONTIN
;wacht tot toetsen worden losgelaten
LOOP2:
        IN    A,(PPI_B)
        AND   &HF0
;rij 6       (Noot2)
        OR    &H06 
        OUT   (PPI_B),A
        IN    A,(PPI_A)
        CP    &B11111111
        JR    NZ,LOOP2

;zet VDP in tekstmode
        CALL  TOTEXT
;breek draaiende programma af
        LD    IX,&H409B
        JP    REBOOT
CONTIN:
        RET
TOTEXT: EQU   &HD2
PPI_A:  EQU   &HA9
PPI_B:  EQU   &HAA
REBOOT: EQU   &H02BF
H_TIMI: EQU   &HFD9F
O_TIMI: DS    5
N_TIMI: JP    START
        RET
        RET
