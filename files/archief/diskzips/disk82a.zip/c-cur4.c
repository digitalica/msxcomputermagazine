/************************************************/
/* File  : c-cur4.c                             */
/* Auteur: Alex Wulms                           */
/* Macro's definieren, eigen functies maken,    */
/* raw file in/out, arrays gebruiken, de        */
/* while loop en type-casting                   */
/************************************************/
#include <stdio.h>
#include <io.h>

/* Definieer de grootte van de in/out buffer */
#define BUFSIZE 30000

/* Alleen voor ASCII C */
#pragma nonrec

/************************************************/
/* encrypt een datablock met een encryptie key  */
/************************************************/
int encrypt(dataptr, aantal, key)
char *dataptr;  /* De buffer met te encrypten data */
int  aantal;    /* Aantal te encrypten bytes */
char key;       /* de encryptie key */
{
  while (aantal--)
    *dataptr++ += key;  /* tel de encryptie key erbij op */
}

/************************************************/
/* de main functie                              */
/************************************************/
int main()
{
  char in_name[80];    /* naam van input file */
  char out_name[80];   /* naam van output file */
  FD in_file, out_file;/* input/output file descriptors */
  int int_key;         /* encryptie key in int formaat */
  char buf[BUFSIZE];   /* in/out buffer */
  int block_len;       /* lengte ingelezen blok */

  printf("Voer de input file naam in : ");
  scanf("%s", in_name);  /* lees in_name in */
  printf("Voer de output file naam in: ");
  scanf("%s", out_name); /* lees out_name in */
  printf("Voer de encryptie key in   : ");
  scanf("%d", &int_key); /* lees de encryptie key in */

  /* open de input file */
  in_file = open(in_name, O_RDWR);
  if (in_file == -1)
    printf("Openen van input file is mislukt\n");
  else {
    /* Maak de output file */
    out_file = creat(out_name);

    /* lees de input file tot alle data op zijn en encrypt */
    /* alles naar de output file */
    while (block_len = read(in_file, buf, BUFSIZE)) {
      encrypt(buf, block_len, (char)int_key);
      write(out_file, buf, block_len);
    }
    /* klaar, sluit de files en keer terug naar dos */
    close(in_file);
    close(out_file);
  }
}

