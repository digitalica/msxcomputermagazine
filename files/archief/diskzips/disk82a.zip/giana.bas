10 ' Einddemo Giana Sisters loader
20 '
30 ' Door Jeffrey Schaaf
40 ' 
50 SCREEN 0: CLS: KEY OFF: LOCATE 0,0,0
60 PRINT "Doe de spel-disk in de drive en druk op een toets";
70 A$=INPUT$(1)
80 NM$=CHR$(127)
90 BLOAD NM$,R
