REM MCCM diskabonnement B-disk
REM
REM Type:
REM FOA                  voor het schietspel FOA
REM BASIC AUTOEXEC.BAS   voor Bridge Spelenderwijs
REM BASIC LINGO.LDR      voor Lingo
REM 
REM Ingepakte promo/demoversies:
REM ABLAZE.LZH     - ABlaze, Cybernetic
REM BOMBRMN2.LZH   - Bomberman 2 van Paragon
REM CDPROMO.LZH    - Core Dump, Parallax
REM MKID.LZH       - MKid, Abyss
REM TOTAL.LZH      - Total Parody, Abyss
