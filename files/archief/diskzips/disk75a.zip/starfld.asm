; STARFLD.ASM
; Door Marco Soijer voor MCCM 75

; Header voor BLOAD-file

          defb #FE
          defw begin
          defw end
          defw exec

          org #C000

; Code vanaf C000h

begin     jp exec          ; Entry point

function  defb #00         ; Functiecode
data      defs #02         ; Datagebied: 2 bytes

regBC     defw #0000       ; Ruimte voor registers bij
regHL     defw #0000       ;  aanroep BASIC
return    defb #00         ; Interne functiecode

; Entry point

exec      ld a,(function)  ; Ophalen functienummer
          dec a
          jp z,startStar   ; Terug uit BASIC
          jp init          ; Eerste aanroep

; Eerste aanroep, aanmaken zestien sterren

init      ld b,16          ; Lusteller
          ld hl,starData   ; Pointer naar stergegevens
nextStar  ld (regBC),bc    ; Redden lusteller voor BASIC
          xor a            ; Returncode 0
          ld (return),a
          jp getStar       ; Aanmaken 1 ster
initLoop  ld bc,(regBC)    ; Herstellen lusteller
          djnz nextStar

; Simulatie

simul     ld b,16          ; Lusteller voor zestien sterren
          ld hl,starData   ; Pointer naar stergegevens
simulLoop ld (regBC),bc    ; Redden lusteller
          ld a,#01         ; Kleurnummer verwijderen ster
          call drawDot
          ld d,(hl)        ; Huidige x
          inc hl
          ld e,(hl)        ; Huidige y
          inc hl
          ld a,(hl)        ; Verandering x
          add a,d
          cp #06           ; Controleren bereiken rand
          inc hl
          jr c,replace
          ld d,a           ; Nieuwe x
          ld a,(hl)        ; Verandering y
          add a,e
          cp #D4           ; Controleren bereiken rand
          jr nc,replace
simulNew  dec hl
          dec hl
          ld (hl),a        ; Opslaan nieuwe y
          dec hl
          ld (hl),d        ; Opslaan nieuwe x
          ld a,#0F         ; Kleurnummer tekenen ster
          call drawDot

          ld de,#0004      ; Verplaatsen pointer
          add hl,de
          ld bc,(regBC)    ; Herstellen lusteller
          djnz simulLoop

          jr simul         ; Volgende stap simulatie

; Vervangen ster door bereiken schermrand

replace   ld a,#01         ; Returncode 1 voor getStar
          ld (return),a
          dec hl           ; Terugzetten pointer
          dec hl
          dec hl
          jp getStar       ; Laten aanroepen BASIC
replRet   dec hl           ; Pointer terug op verandering y
          ld a,#6A         ; Beginpositie y
          ld d,#80         ; Beginpositie x
          jp simulNew      ; Simuleren met nieuwe ster

; Aanmaken nieuwe ster

getStar   ld (regHL),hl    ; Redden pointer voor BASIC
          ld a,#01         ; Functienummer voor BASIC:
          ld (function),a  ;  lever richting van nieuwe ster
          ret              ; Terug naar BASIC

startStar ld hl,(regHL)    ; Herstellen pointer
          ld (hl),#80      ; Beginpositie x
          inc hl
          ld (hl),#6A      ; Beginpositie y
          inc hl
          ld a,(data+#00)  ; Overnemen x-snelheid
          ld (hl),a
          inc hl
          ld a,(data+#01)  ; Overnemen y-snelheid
          ld (hl),a
          inc hl

          ld a,(return)    ; Ophalen returncode
          dec a
          jp z,replRet     ; Vervanging
          jp initLoop      ; Beginsterren

; Zetten punt op grafisch scherm

drawDot   ld e,(hl)        ; Overnemen positie
          inc hl
          ld d,(hl)        ; Ophalen y
          dec hl
          ex de,hl         ; Pointer en VRAM adres
          srl h            ; Adres delen door twee
          rr l
          call #0177       ; Aanroepen BIOS NWrVrm
          ex de,hl
          ret

; Gegevens voor zestien sterren

starData  defs 64          ; x, y, dx, dy

end       equ $
