PROGRAM Screen0Demo;

{$i MCSCR0.INC}

PROCEDURE WachtOpToets;
VAR kar : CHAR;
BEGIN
  WRITELN('druk een toets voor vervolg');
  REPEAT
  UNTIL KEYPRESSED;
  READ(KBD,kar)
END;

PROCEDURE VulScherm(page : BYTE; kar : CHAR);
VAR tel : BYTE;
    st  : STRING[80];
BEGIN
  FILLCHAR(st,80,kar);
  st[0]:=#79;
  FOR tel:=0 TO 23 DO
    Fast_Str(0,tel,page,st)
END;

PROCEDURE BouwMenu(num,wt:BYTE);
VAR x,y : BYTE;
    numstr : STRING[2];
BEGIN
  STR(num,numstr);
  x:=RANDOM(62+1);
  y:=RANDOM(21+1);
  SaveScreen(x,y,x+17,y+3,0);
  Fast_Str(x,y,0,#24+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#25);
  Fast_Str(x,y+1,0,#22+' dit is menu '+numstr+'.'+#22);
  Fast_Str(x,y+2,0,#26+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#23+#27);
  DELAY(wt);
END;

PROCEDURE Demo;
VAR tel1,tel2 : INTEGER;
BEGIN
  SaveScreen(0,0,79,23,0);
  CLRSCR;
  WRITELN('Deze korte demo laat zien wat er ondermeer mogelijk is met de');
  WRITELN('screen 0 routines uit MCCM nr 75.');
  WRITELN;
  WRITELN('Deze routines zijn beschikbaar gesteld door: Olaf Benneker');
  WRITELN('(C) 1994  Msx Computer Club Enschede.');
  WRITELN;
  WRITELN('Deze routines zijn vrij te gebruiken in uw eigen software.');
  WRITELN('Veel plezier ermee.');
  WRITELN;
  WRITELN('Ik vul nu de niet zichtbare pagina''s 4 t/m 13');
  FOR tel1:=0 TO 9 DO
  BEGIN
    WRITELN('pagina ',tel1+4,' wordt gevuld.');
    VulSCherm(tel1+3,CHR(48+tel1))
  END;
  WRITELN('U zag niet zo vlug wat er nu precies hierboven gebeurde?');
  WachtOpToets;
  WRITELN('Dan zal ik iets soortgelijk op dit scherm doen.');
  WRITELN('Ik zal dit scherm even volzetten met de karakters ''A''t/m''Z''.');
  WachtOpToets;
  FOR tel1:=1 TO 26 DO
    VulScherm(0,CHR(64+tel1));
  WRITELN('Ging dit te vlug, dan zal ik het nog eens herhalen.');
  WRITELN('Ik zal tussen de letters even wachten zodat u ze kunt meelezen.');
  WachtOpToets;
  FOR tel1:=1 TO 26 DO
  BEGIN
    VulScherm(0,CHR(64+tel1));
    DELAY(70);
  END;
  WRITELN('zoals gezegd had ik 10 schermen gevuld met cijfers.');
  WRITELN('ik zal ze nu even allemaal laten zien.');
  WachtOpToets;
  FOR tel2:=0 TO 9 DO
    FOR tel1:=1 TO 9 DO
    BEGIN
      Screen0page(tel1+3);
    END;
  Screen0page(0);
  CLRSCR;
  WRITELN('ging dat te snel?, dit waren de 10 pagina''s, maar wel allemaal 10 keer!');
  WRITELN('U zag alleen maar een korte flits?');
  WRITELN('Dan zal ik ze nog een keer laten zien, maar nu elke pagina 500 keer!');
  WachtOpToets;
  FOR tel2:=0 TO 499 DO
    FOR tel1:=1 TO 9 DO
    BEGIN
      Screen0page(tel1+3);
    END;
  Screen0page(0);
  WRITELN('Stel nu dat u wat menu''s op het scherm wilt opbouwen en weer weghalen');
  WachtOpToets;
  FOR tel1:=0 TO 9 DO BouwMenu(tel1,0);
  FOR tel1:=0 TO 9 DO RestoreScreen(0);
  WRITELN('Ging dit ook weer te snel, dan nu nog een keer met een wachttijd er tussen.');
  WachtOpToets;
  FOR tel1:=0 TO 9 DO
    BouwMenu(tel1,100);
  FOR tel1:=0 TO 9 DO
  BEGIN
    RestoreScreen(0);
    DELAY(100);
  END;
  WRITELN('Weet u nog wat er op het scherm stond voordat we begonnen?');
  WachtOpToets;
  RestoreScreen(0);
  SaveScreen(0,0,79,23,0);
  GOTOXY(1,24);
  WRITELN('Dat was u al weer bijna vergeten nietwaar?');
  WRITELN('Ik had overigens pagina 4 t/m 13 al eens gevuld met getallen.');
  WRITELN('Ik zal ze allemaal nog eens 500 keer laten zien');
  WachtOpToets;
  FOR tel2:=0 TO 499 DO
    FOR tel1:=1 TO 9 DO
    BEGIN
      Screen0page(tel1+3);
    END;
  Screen0page(0);
  WachtOpToets;
  WRITELN('Dit laat denk ik aardig de kracht van deze bibliotheek zien.');
  WRITELN('Met wat fantasie zijn er leuke effecten te bereiken, en u kunt nu');
  WRITELN('zondermeer leuke scherm 0 programma''s maken.');
  WachtOpToets;
  RestoreScreen(0)
END;

BEGIN
  InitVDPStack($FF00,0);
  Demo
END.

