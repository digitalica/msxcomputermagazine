10 ' ; FILVR2
20 ' ;
30 ' ; Vul het MSX2 VideoRAM
40 ' ;
50 ' ; MSX Computer Magazine
60 ' ; door MJV
70 ' ;
80 '
90 ' equ VDPWD, 7     ;Adres VDP schrijfpoort
100 '
110 ' org $0c000       ;Startadres op 0C000H
120 '
130 ' FILVR2:
140 '   ld a,4         ;Schrijfadres instellen op
150 '   ld hl,0        ; 4e 16 kB blok, adres 0
160 '   call NSTWRT    ;Zet VDP schrijfadres
170 '   ld bc,(VDPWD)  ;C=Data schrijfpoort
180 '   ld b,212       ;212 lijnen
190 ' LINELP:          ;Lijn-lus
200 '   ld a,b         ;A= 1e Kleur
210 ' DOTLP:
220 '   out (c),a      ;Zet pixelkleur A
230 '   inc a          ;Kleurnummer 1 hoger
240 '   cp b           ;255 pixels gehad?
250 '   jr nz,DOTLP    ; Nee, => Volgende
260 '   djnz LINELP    ; Ja, volgende lijn
270 '   ret
280 '
290 ' ;Set vdp write/read adres A:HL
300 '
310 ' NSTWRT:
320 '   di             ;Geen interrupts
330 '   ld bc,(VDPWD)
340 '   inc c          ;C=VDP commandopoort
350 '   out (c),a      ;Schrijf data voor reg. 14
360 '   ld a,14        ;En dan het registernummer
370 '   set 7,a        ;Bit 7 op 1 zetten, is
380 '   out (c),a      ; "schrijf VDP register"
390 '   set 6,h        ;Zet Adres Write-flag
400 '   res 7,h        ;Wis Schrijf register vlag
410 '   out (c),l      ;Schrijf lage adresbyte
420 '   out (c),h      ;Schrijf hoge adresbyte
430 '   ei             ;Interrupt mag weer
440 '   ret
