10 ' ; PRTUSR
20 '
30 ' ; PRTUSR wordt aangeroepen d.m.v.
40 ' ; A$=USR(A$), waarna A$ afgedrukt wordt
50 '
60 ' ; MSX Computer Magazine
70 ' ; door MJV
80 '
90 '  equ VDPWD, 7       ;VDP write data poort
100 '  equ CSRY, $f3dc   ;Huidige XY positie
110 '  equ VALTYP, $f663 ;USR Parameter type
120 '  equ FACLO, $f7f8  ;USR Parameter adres
130 '
140 '  org $c000     ;Startadres=&HC000
150 '
160 'PRTSTR:
170 '  ld hl,(CSRY)  ;H=Kolom  L=Regel
180 '  call SETXY    ;Zet VDP schrijfklaar
190 '  ld a,(VALTYP) ;Haal type van USR parameter
200 '  cp 3          ;Is het een string?
210 '  ret nz        ; Nee, => Stop
220 '  ld hl,(FACLO) ; Ja, haal stringadres
230 '  ld b,(hl)     ;Haal stringlengte in B
240 '  inc b
250 '  dec b         ;Lege regel?
260 '  ret z         ; Ja, => Klaar
270 '  inc hl        ;Zet HL op 1e teken
280 '  ld e,(hl)     ;Haal stringadres in DE
290 '  inc hl
300 '  ld d,(hl)     ;Hoogste byte het laatst
310 '  ex de,hl      ;Stringadres naar HL
320 '  ld a,(VDPWD)
330 '  ld c,a        ;VDP dataschrijfpoort in C
340 '  otir          ;B bytes van (HL) naar VDP
350 '  ret           ; poort C
360 '
370 ' ;Zet de VDP schrijfklaar
380 ' ; In: L=Regelnummer
390 ' ;     H=Kolomnummer
400 '
410 'SETXY:
420 '  dec h         ;Kolom en regelnummer
430 '  dec l         ; beide 0-based maken
440 '  ld c,h        ;Kolom bewaren in C
450 '  ld h,0        ;Zet kolom op 0
460 '  ld d,h        ;Vermenigvuldig met 40/80
470 '  ld e,l        ; DE=HL*1
480 '  add hl,hl     ; HL=HL*2
490 '  add hl,hl     ; *4
500 '  add hl,de     ; *5
510 '  add hl,hl     ; *10
520 '  add hl,hl     ; *20
530 '  add hl,hl     ; *40 tekens per regel
540 ' ;add hl,hl     ; bij 80 tekens: 1e ";" weg!
550 '  ld b,d        ;B wordt nul
560 '  add hl,bc     ;Bereken VideoRAM adres
570 'SETWRT:
580 '  set 6,h       ;Zet Adres schrijfvlag
590 '  res 7,h       ;Wis "Schrijf register vlag"
600 '  di            ;Interrupt verstoort de VDP
610 '  ld bc,(VDPWD) ;Haal Write Data poort
620 '  inc c         ;Bereken commandopoort adres
630 '  out (c),l     ;Geef het te beschrijven
640 '  out (c),h     ; VRAM adres door aan de VDP
650 '  ei            ;Interrupt mag weer
660 '  ret
