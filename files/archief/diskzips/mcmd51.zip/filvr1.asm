10 ' ; FILVR1.ASM
20 ' ;
30 ' ; Vul het MSX1 VideoRAM met
40 ' ;  karakters
50 ' ;
60 ' ; MSX Computer Magazine
70 ' ; door MJV
80 '
90 ' equ VDPWD, 7    ;Adres VDP schrijfpoort
100 ' equ KAR, $2a    ;Karakter = sterretje
110 '
120 ' org $c000
130 '
140 'FILVR1:
150 '  ld a, KAR     ;Schrijf driehonderd
160 '  ld bc,300     ; karretjes vanaf
170 '  ld hl,0       ; VideoRAM adres 0
180 '
190 '  push af       ;Bewaar het teken
200 '  push bc       ;Aantal te schrijven tekens
210 '  call SETWRT   ;Zet VDP schrijfadres [HL]
220 '  pop hl        ;HL=Aantal
230 '  pop af        ; A=Karakter
240 '  ld bc,(VDPWD) ;C wordt VDP write poort
250 '  ld b,h        ;B wordt teller (highbyte)
260 '  inc l         ;L is lowbyte van teller
270 '  dec l         ;Low byte=0?
280 '  jr z,FILOOP   ; Ja, => Highbyte is o.k.
290 '  inc b         ; Nee, maak hogebyte 1-based
300 'FILOOP:         ;Hier begint de lus
310 '  out (c),a     ;Schrijf kar. naar het VRAM
320 '  dec l         ; verlaag lage byte
330 '  jp nz,FILOOP  ; niet nul => volgende
340 '  djnz FILOOP   ;Lus voor hoge byte
350 '  ret           ;B=0, L=0 => klaar!
360 '
370 ' ;Zet vdp schrijfklaar op VRAM adres [HL]
380 '
390 'SETWRT:
400 '  set 6,h       ;Zet Adres schrijfvlag
410 '  res 7,h       ;Wis "Schrijf register vlag"
420 '  di            ;Interrupt verstoort de VDP
430 '  ld bc,(VDPWD) ;Haal Write Data poort
440 '  inc c         ;Bereken commandopoort adres
450 '  out (c),l     ;Geef het te beschrijven
460 '  out (c),h     ; VRAM adres door aan de VDP
470 '  ei            ;Interrupt mag weer
480 '  ret
