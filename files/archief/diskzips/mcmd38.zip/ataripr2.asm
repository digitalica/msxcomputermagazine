        ORG   0D603H

MSXDOS: EQU   0F37DH
NWRVRM: EQU   0177H
KILBUF: EQU   0156H
BEEP:   EQU   0C0H
LPTOUT: EQU   0A5H
LPTSTT: EQU   0A8H
CHPUT:  EQU   0A2H

EXTROM: EQU   015FH
SETPAG: EQU   013DH
CLS:    EQU   0115H


ACPAGE: EQU   0FAF6H
DPPAGE: EQU   0FAF5H



TELLER: DEFB  0,0
TELLE2: DEFB  0,0


        LD    A,(0F3E0H)      ;INTERRUPT UIT, MEER SNELHEID
        LD    B,A
        LD    C,1
        PUSH  BC
        AND   11011111B
        LD    B,A
        CALL  47H

        PUSH  IX              ;BEWAAR VOOR BASIC-INTERPRETER

        LD    (SAVESP),SP     ;BEWAAR SP

        LD    A,14
        LD    (KE1213+1),A

        CALL  LPTSTT          ;PRINTER AAN ???
        JP    Z,PRIUIT

DRUKA4: LD    HL,PRINT4       ;STUUR PRINT4 NAAR PRINTER
        LD    B,3
DRA4:   LD    A,(HL)
        CALL  LPTOUT
        INC   HL
        DJNZ  DRA4
        JP    C,BREAK
        JR    ATARI
PRINT4: DEFB  27,"3",24       ;LINE SPACING 24/216 INCH

ATARI:  LD    A,255           ;TWEE KEER DOORLOPEN
LOADNE: INC   A
        PUSH  AF

        LD    HL,9000H-640
        LD    (TELLER),HL

        LD    HL,KE1213+1
        DEC   (HL)

        LD    DE,9000H-640    ;SET TRANSFER ADRES OP &H9000-320
        LD    C,1AH
        CALL  MSXDOS

        LD    DE,(0D000H)     ;FCB (WEGGESCHREVEN VANUIT BASIC)
        LD    HL,16000+640    ;LEES 16640 BYTES
        LD    C,27H
        CALL  MSXDOS

KE1213: LD    A,12
KEER12: PUSH  AF

        CALL  PRIREG          ;PRINT REGEL

        CALL  DRUKA3

        LD    HL,(TELLER)     ;VOLGENDE REGEL (OOK IN GEHEUGEN)
        LD    DE,8*80
        ADD   HL,DE
        LD    (TELLER),HL

        CALL  PRIREG          ;PRINT REGEL

        CALL  DRUKA3

        LD    HL,(TELLER)     ;VOLGENDE REGEL
        LD    DE,8*80
        ADD   HL,DE
        LD    (TELLER),HL

        POP   AF
        DEC   A
        JR    NZ,KEER12

        POP   AF              ;IN TOTAAL TWEE KEER LADEN
        AND   A
        JP    Z,LOADNE

STOP:   LD    SP,(SAVESP)
        POP   IX
        POP   BC
        CALL  47H
        EI                    ;INTERRUPT WEER AAN
        RET                   ;TERUG NAAR BASIC

PRIREG: CALL  DRUKA1          ;REGEL PRINTEN

        LD    HL,(TELLER)
        LD    (TELLE2),HL

        LD    A,80
PRIR9:  PUSH  AF

        LD    B,10000000B
        LD    C,8

PRIR0:  PUSH  BC

        XOR   A
        LD    (PRISV),A

        LD    A,(HL)
        AND   B
        JR    Z,PRIR1
        LD    A,(PRISV)
        OR    10000000B
        LD    (PRISV),A

PRIR1:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR2
        LD    A,(PRISV)
        OR    01000000B
        LD    (PRISV),A


PRIR2:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR3
        LD    A,(PRISV)
        OR    00100000B
        LD    (PRISV),A


PRIR3:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR4
        LD    A,(PRISV)
        OR    00010000B
        LD    (PRISV),A


PRIR4:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR5
        LD    A,(PRISV)
        OR    00001000B
        LD    (PRISV),A


PRIR5:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR6
        LD    A,(PRISV)
        OR    00000100B
        LD    (PRISV),A


PRIR6:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR7
        LD    A,(PRISV)
        OR    00000010B
        LD    (PRISV),A


PRIR7:  LD    DE,80
        ADD   HL,DE
        LD    A,(HL)
        AND   B
        JR    Z,PRIR8
        LD    A,(PRISV)
        OR    00000001B
        LD    (PRISV),A

PRIR8:  LD    A,(PRISV)       ;BYTE COMPLEET ==> NAAR PRINTER
        CALL  LPTOUT

        LD    HL,(TELLE2)
        POP   BC
        RRC   B
        DEC   C
        JP    NZ,PRIR0

        LD    HL,(TELLE2)
        INC   HL
        LD    (TELLE2),HL
        POP   AF
        DEC   A
        JP    NZ,PRIR9
        RET

PRISV:  DEFB  0




DRUKA1: LD    HL,PRINT1       ;STUUR PRINT1 NAAR PRINTER
        LD    B,5
DRA1:   LD    A,(HL)
        CALL  LPTOUT
        INC   HL
        DJNZ  DRA1
        RET

DRUKA2: LD    HL,PRINT2       ;STUUR PRINT2 NAAR PRINTER
        LD    B,4
DRA2:   LD    A,(HL)
        CALL  LPTOUT
        INC   HL
        DJNZ  DRA2
        JP    C,BREAK
        RET

DRUKA3: LD    HL,PRINT3       ;STUUR PRINT3 NAAR PRINTER
        LD    B,2
DRA3:   LD    A,(HL)
        CALL  LPTOUT
        INC   HL
        DJNZ  DRA3
        JP    C,BREAK
        RET

BREAK:  LD    HL,BRETXT
        LD    B,24
BRE1:   LD    A,(HL)
        CALL  CHPUT
        INC   HL
        DJNZ  BRE1
        JP    STOP
BRETXT: DEFB  "PRINTEN ONDERBROKEN !!",13,10

PRIUIT: LD    HL,UITTXT
        LD    B,22
UIT1:   LD    A,(HL)
        CALL  CHPUT
        INC   HL
        DJNZ  UIT1
        JP    STOP
UITTXT: DEFB  "PRINTER NIET AAN !!!",13,10

; <ESC>,"*",4,640
PRINT1: DEFB  27,"*",4,128,2  ;GRAPHICS MODE LC-10 (80 DOTS PER INCH)
; <ESC>,"J",2,<CR>
PRINT2: DEFB  27,"J",1,13     ;PERFORM ONE 2/216-INCH LINE FEED
; <CR>,<LF>
PRINT3: DEFB  13,10

SAVESP: DEFB  0,0
,<CR>
PRINT2: DEFB  27,"J",