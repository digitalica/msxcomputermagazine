        ORG   0D003H

MSXDOS: EQU   0F37DH
NWRVRM: EQU   0177H
KILBUF: EQU   0156H
BEEP:   EQU   0C0H

EXTROM: EQU   015FH
SETPAG: EQU   013DH
CLS:    EQU   0115H


ACPAGE: EQU   0FAF6H
DPPAGE: EQU   0FAF5H



TELLER: DEFB  0,0
TELLE2: DEFB  0,0

        LD    A,(0F3E0H)      ;INTERRUPT UIT, MEER SNELHEID
        LD    B,A
        LD    C,1
        PUSH  BC
        AND   11011111B
        LD    B,A
        CALL  47H

        PUSH  IX              ;BEWAAR VOOR BASIC-INTERPRETER

        LD    HL,(0F7F8H)     ;CENTEREN (8 IS MIDDEN)
        LD    (CENTER+1),HL

        LD    HL,4000H
        LD    (TELLE2),HL     ;ACTIEVE VRAM ADRES VIA DIRECTE VDP I/O

        LD    HL,0
        LD    (LNSAVE),HL

        CALL  KILBUF          ;TOETSENBORDBUFFER LEEG
        CALL  BEEP            ;BEEP

        LD    A,1             ;SET PAGE 1,1: CLS
        LD    (ACPAGE),A
        LD    (DPPAGE),A
        LD    IX,SETPAG
        CALL  EXTROM
        LD    IX,CLS
        CALL  EXTROM
        XOR   A               ;SET PAGE ,0: CLS
        LD    (ACPAGE),A
        LD    IX,CLS
        CALL  EXTROM

        LD    A,255           ;TWEE KEER DOORLOPEN
LOADNE: INC   A
        LD    (LNSAVE),A

CENTER: LD    HL,8
        LD    (TELLER),HL     ;ACTIEVE RAM ADRES + &H9000

        LD    DE,9000H        ;SET TRANSFER ADRES OP &H9000
        LD    C,1AH
        CALL  MSXDOS

        LD    DE,(0D000H)     ;FCB (WEGGESCHREVEN VANUIT BASIC)
        LD    HL,16000        ;LEES 16000 BYTES
        LD    C,27H
        CALL  MSXDOS

        LD    A,100
REGELS: PUSH  AF              ;100 * 2 REGELS = 200 (*2 = 400)

        CP    72
        JR    NZ,REG1
        LD    A,(LNSAVE)
        AND   A
        JR    Z,REG1
        LD    A,1
        LD    (LNSAV1),A
        XOR   A
        LD    HL,(TELLE2)
        LD    DE,4000H
        SBC   HL,DE
        LD    (TELLE2),HL

;       XOR   A               ;SET PAGE ,0
;       LD    (ACPAGE),A

REG1:   EI                    ;GEEF AAN DAT NIEUWE REEKS VOLGT
        DI                    ;MAAK VDP KLAAR VOOR SCHRIJVEN
        LD    A,(LNSAV1)
        OUT   (99H),A
        LD    A,8EH
        OUT   (99H),A
        LD    HL,(TELLE2)
        LD    A,L
        OUT   (99H),A
        LD    A,H
        OUT   (99H),A

        LD    A,64
OPN1:   PUSH  AF

        CALL  REAWRI

        POP   AF
        DEC   A
        JR    NZ,OPN1

        LD    HL,(TELLER)     ;TELLER=TELLER+16
        LD    DE,16
        ADD   HL,DE
        LD    (TELLER),HL

        LD    HL,(TELLE2)     ;TELLE2=TELLE2-128
        LD    DE,128
        SBC   HL,DE
        LD    (TELLE2),HL

        EI
        DI                    ;MAAK VDP KLAAR VOOR SCHRIJVEN
        LD    A,(LNSAV1)      ;PAGE 1
        OR    2
        OUT   (99H),A
        LD    A,8EH
        OUT   (99H),A
        LD    HL,(TELLE2)
        LD    A,L
        OUT   (99H),A
        LD    A,H
        OUT   (99H),A


;       LD    A,1
;       LD    (ACPAGE),A      ;SET PAGE ,1

        LD    A,64
OPN2:   PUSH  AF

        CALL  REAWRI

        POP   AF
        DEC   A
        JR    NZ,OPN2

        LD    HL,(TELLER)     ;TELLER=TELLER+16
        LD    DE,16
        ADD   HL,DE
        LD    (TELLER),HL

        POP   AF              ;VOLGENDE REGEL
        DEC   A
        JP    NZ,REGELS

        LD    A,(LNSAVE)      ;IN TOTAAL TWEE KEER LADEN
        AND   A
        JP    Z,LOADNE

        POP   IX
        POP   BC
        CALL  47H
        EI                    ;INTERRUPT WEER AAN
        RET                   ;TERUG NAAR BASIC


REAWRI: LD    HL,(TELLER)
        LD    DE,9000H
        ADD   HL,DE
        LD    A,(HL)          ;A = PEEK &H9000+ (TELLER)
        PUSH  AF              ;BEWAAR

        LD    E,A
        LD    D,0
        LD    HL,0D200H
        ADD   HL,DE
        LD    A,(HL)          ;A = PEEK &HD200 + A

        OUT   (98H),A         ;VPOKE (TELLE2),A: TELLE2 = TELLE2 + 1
        LD    HL,(TELLE2)
        INC   HL
        LD    (TELLE2),HL


        POP   AF              ;HAAL AF

        LD    E,A
        LD    D,0
        LD    HL,0D300H
        ADD   HL,DE
        LD    A,(HL)          ;A = PEEK &HD300 + A

        OUT   (98H),A         ;VPOKE (TELLE2),A: TELLE2 = TELLE2 + 1
        LD    HL,(TELLE2)
        INC   HL
        LD    (TELLE2),HL

        LD    HL,(TELLER)
        INC   HL              ;TELLER = TELLER + 1
        LD    (TELLER),HL

        RET

LNSAVE: DEFB  0
LNSAV1: DEFB  0

;Van &HD200 tot &HD3FF komen de codes.
;Deze staan in de file ATARI.BIN

        RET

LNSAVE: DEFB