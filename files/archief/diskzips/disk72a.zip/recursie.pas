
PROGRAM Recursie;
TYPE str16=STRING[16];
VAR tel : INTEGER;

      {$A-} {recursieve versie}
FUNCTION Bin(waarde : INTEGER) : STR16;
BEGIN
  BIN:='';
  IF waarde>0 THEN 
    Bin:=Bin(waarde DIV 2)+CHR((waarde AND 1)+48)
END;
      {$A+}

      {niet recursieve versie}
FUNCTION BIN2(waarde : INTEGER) : str16;
VAR rij : str16;
BEGIN
  rij:='';
  WHILE waarde>0 DO
  BEGIN
    rij:=CHR((waarde and 1)+48)+rij;
    waarde:=waarde div 2
  END;
  bin2:=rij
END;

BEGIN
  FOR tel:=0 TO 20 DO
    WRITELN(Bin(tel):16,bin2(tel):20)
END.

