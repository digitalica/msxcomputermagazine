PROGRAM IOCheck;
VAR fil   : TEXT;  
    regel : STRING[255];
BEGIN
  ASSIGN(fil,'demo.txt');
  {$i-}
  RESET(fil);
  {$i+}
  IF IORESULT<>0 THEN
    WRITELN('File DEMO.TXT is niet aanwezig!')
  ELSE	
    REPEAT
      READLN(fil,regel);
      WRITELN(regel)
    UNTIL EOF(fil);
  CLOSE(fil);
END.	  

