
PROGRAM RangeCheck;
VAR lijst_a : ARRAY[0..99] OF BYTE;
    lijst_b : ARRAY[0..99] OF BYTE;
    tel     : INTEGER;
BEGIN
  FILLCHAR(lijst_a,100,55);
  FILLCHAR(lijst_b,100,44);
  {$R+}
  FOR tel:=50 TO 150 DO lijst_b[tel]:=66;
  FOR tel:=0 TO 99 DO
    WRITELN(lijst_a[tel],lijst_b[tel]:10);
END.

