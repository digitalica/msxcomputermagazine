; MAP1.WAS

; Bereken omvang mappergeheugen en zet dat in HL
; Het aantal pages (HL/16) komt in BC terecht

        ORG   #C000           ; testadresje

GO:     IN    A,(#FF)         ; haal nulwaarde

        CPL                   ; inverteren waarde A

; bit 7 van A kan gezet zijn, dus verder met HL

        LD    L,A             ; aantal mapperpagina's
        LD    H,0             ; wordt in HL gezet
        INC   HL              ; pagina nul doet ook mee

        PUSH  HL              ; aantal in BC zetten
        POP   BC

        ADD   HL,HL           ; *  2
        ADD   HL,HL           ; *  4
        ADD   HL,HL           ; *  8
        ADD   HL,HL           ; * 16 => aantal Kb's

        RET                   ; klaar

EIND:   NOP

; Testcode
 8
        ADD   HL,HL           ; * 16 => aantal Kb's

        RET                   ; klaar

EIND