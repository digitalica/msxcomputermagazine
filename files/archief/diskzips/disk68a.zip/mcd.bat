MD %1
CD %1
