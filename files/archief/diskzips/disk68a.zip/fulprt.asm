fulPrt  ld de,decStr+5
        xor a
        ld (de),a
        ld c,#F6

getDig  xor a
        ld b,16
divide  adc hl,hl
        adc a,a
        add a,c
        jr c,okSub
        sub c
okSub   djnz divide
        adc hl,hl
        add a,"0"
        dec de
        ld (de),a
        ld a,h
        or l
        jr nz,getDig

        ld hl,decStr
        ex de,hl
        ld bc,5
        ldir
        ret
