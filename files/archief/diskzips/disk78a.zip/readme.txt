
                    Pumpkin Adventure III - promo version

                                (c) UMAX 1995

You can start the promo either from BASIC or from MSX-DOS. In BASIC type RUN
"PA3PROMO.BAS" and press [RETURN]. In MSX-DOS type PA3PROMO at the DOS prompt
and press [RETURN].

This promo version can be installed on harddisk very easily. Copy the
following files to your harddisk:

                  PA3PROMO.BAT
                  PA3PRDOS.BAS
                  PA3PROMO.BIN
                  PA3PROMO.LIB
                  SAVEGAME.PA3

You can start the game by starting the batchfile PA3PROMO.BAT.

If you like this promo version, please purchase the full version! Write to the
address below for more information. Shipment throughout the world is possible!

                              Stichting Sunrise
                                 P.O. Box 178
                               1530 AD  Wormer
                               The Netherlands

This promo version is Public Domain, please copy it as much as possible!

System requirements:

Computer: MSX2 or higher
Main RAM: 128 kB or more (extra memory is used to load less)
VRAM    : 128 kB
Music   : MSX-MUSIC and/or MSX-AUDIO
