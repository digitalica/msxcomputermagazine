/************************************************/
/* File  : struct.c                             */
/* Auteur: Alex Wulms                           */
/* Eigen variabele types definieren en          */
/* structures gebruiken                         */
/************************************************/
#include <stdio.h>

/************************************************/
/* Definieer, met behulp van een structure, een */
/* eigen, samengesteld variabele type           */
/************************************************/
typedef struct {
  int x,y;
  TINY color;
} Pixel;

/************************************************/
/* Bereken het gemiddelde over twee pixels      */
/************************************************/
VOID AvgPixel(p1, p2, p_out)
Pixel *p1, *p2, *p_out;
{
  p_out->x = (p1->x + p2->x)/2;
  p_out->y = (p1->y + p2->y)/2;
  p_out->color = (p1->color + p2->color)/2;
}

/************************************************/
/* Vraag de gebruiker om de parameters voor een */
/* pixel in te voeren                           */
/************************************************/
VOID GetPixel(pixel)
Pixel *pixel;
{
  int tmp_color;

  printf("Geef de x-coordinaat: ");
  scanf("%d", &pixel->x);
  printf("Geef de y-coordinaat: ");
  scanf("%d", &pixel->y);
  printf("Geef de kleur       : ");
  scanf("%u", &tmp_color);
  pixel->color = (TINY)tmp_color;
  printf("\n");
}

/************************************************/
/* En dan nog de main() functie                 */
/************************************************/
VOID main()
{
  Pixel p1, p2, p3;

  printf("Voer de data voor pixel 1 in\n");
  GetPixel(&p1);

  printf("Voer de data voor pixel 2 in\n");
  GetPixel(&p2);

  AvgPixel(&p1, &p2, &p3);
  printf("De gemiddelde x-coordinaat: %d\n", p3.x);
  printf("De gemiddelde y-coordinaat: %d\n", p3.y);
  printf("De gemiddelde kleur       : %u\n", (unsigned)p3.color);
}

