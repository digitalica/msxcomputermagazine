{$R+}
PROGRAM priem50000;

CONST setgroote =256;
      maxelement=255;
      setdelen=97;

TYPE natuurlijk = 0..MAXINT;

VAR zeef,priemen      : ARRAY[0..setdelen] OF SET OF 0..maxelement;
    volgpriem         : RECORD
                          deel,element : natuurlijk;
                        END;
    veelvoud,nwepriem,
    p,n,teller        : natuurlijk;  { zou ook INTEGER mogen zijn}
    leeg              : BOOLEAN;
    getal             : INTEGER;     { mag niet NATUURLIJK zijn}

PROCEDURE WriteNeg(w : INTEGER);
BEGIN
  w:=w-30000;
  WRITE(w DIV 10000+3:2,
        w MOD 10000 DIV 1000:1,
        w MOD 1000 DIV 100:1,
        w MOD 100 DIV 10:1,
        w MOD 10:1);
END;

BEGIN
  { toekennen beginwaarden }
  FOR p:=0 TO setdelen DO
  BEGIN
    zeef[p]:=[0..maxelement];
    priemen[p]:=[]
  END;
  zeef[0]:=zeef[0]-[0];
  leeg:=FALSE;
  volgpriem.deel:=0;
  volgpriem.element:=1;

  { zoek volgende priem }
  WRITELN('De priemgetallen worden berekend ');
  WITH volgpriem DO
  REPEAT
    WHILE NOT (element IN zeef[deel]) DO element:=SUCC(element);
    priemen[deel]:=priemen[deel]+[element];
    nwepriem:=SUCC(element SHL 1);
    veelvoud:=element;
    p:=deel;
    WHILE p<=setdelen DO
    BEGIN
      zeef[p]:=zeef[p]-[veelvoud];
      p:=p+(deel SHL 1);
      veelvoud:=veelvoud+nwepriem;
      WHILE veelvoud>maxelement DO
      BEGIN
        p:=SUCC(p);
        veelvoud:=veelvoud-setgroote
      END
    END;
    IF zeef[deel]=[] THEN
    BEGIN
      leeg:=true;
      element:=0
    END;
    WHILE leeg AND (deel<setdelen) DO
    BEGIN
      deel:=deel+1;
      leeg:=zeef[deel]=[]
    END
  UNTIL leeg;

  { weergeven van de priemgetallen }
  WRITELN('En hier zijn ze dan:');
  teller:=0;
  FOR p:=0 TO setdelen DO
    FOR n:=0 TO maxelement DO
      IF n IN priemen[p] THEN
      BEGIN
        getal:=2*n+1+p*setgroote*2;
        IF getal<0 THEN WriteNeg(getal) ELSE WRITE(getal:6);
        teller:=SUCC(teller);
        IF (teller MOD 8)=0 THEN WRITELN;
      END;
END.
