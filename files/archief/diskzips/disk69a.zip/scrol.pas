PROGRAM TekstScrol;

CONST maxmem = 3000;

TYPE str255 = STRING[255];

VAR rij         : ARRAY[0..maxmem] OF CHAR;
    regel       : str255;
    startpos,
    eindpos,
    regelaantal,
    maxpos      : INTEGER;
    tel,lengte  : BYTE;
    k           : CHAR;
    file1       : TEXT;

PROCEDURE PointerDown(VAR pointer:INTEGER);
BEGIN
  pointer:=pointer-BYTE(rij[pointer-1])-2
END;

PROCEDURE PointerUP(VAR pointer:INTEGER);
BEGIN
  pointer:=pointer+BYTE(rij[pointer])+2
END;

PROCEDURE BouwScherm;
VAR y : BYTE;
BEGIN
  y:=0;
  CLRSCR;
  eindpos:=startpos;
  REPEAT
    MOVE(rij[eindpos],regel,80);
    GOTOXY(1,SUCC(y));
    WRITE(regel);
    y:=SUCC(y);
    PointerUp(eindpos)
  UNTIL (y=24) OR (eindpos>=maxpos)
END;

PROCEDURE ScrolUp;
BEGIN
  IF startpos=0 THEN EXIT;
  PointerDown(startpos);
  PointerDown(eindpos);
  MOVE(rij[startpos],regel,80);
  GOTOXY(1,1);
  INSLINE; {eerst naar beneden scrollen}
  WRITE(regel)
END;

PROCEDURE ScrolDown;
BEGIN
  IF eindpos=maxpos THEN EXIT;
  MOVE(rij[eindpos],regel,80);
  GOTOXY(1,24);
  WRITELN; {eerst omhoog scrollen}
  WRITE(regel);
  PointerUp(startpos);
  PointerUp(eindpos)
END;

PROCEDURE CharOut(k:CHAR);
BEGIN
  INLINE($3A/K/$FD/$2A/$C0/$FC/$DD/
         $21/$A2/$00/$CD/$1C/$00)
END;

BEGIN
  CONOUTPTR:=ADDR(CharOut);
  ASSIGN(file1,'scrol.pas');
  RESET(file1);
  startpos:=0;
  eindpos:=0;
  regelaantal:=0;
  maxpos:=0;
  REPEAT
    READLN(file1,regel);
    REPEAT
      regelaantal:=SUCC(regelaantal);
      lengte:=LENGTH(regel);
      IF lengte>79 THEN lengte:=79;
      IF maxpos+lengte>maxmem THEN
      BEGIN
        CLRSCR;
        WRITELN('textfile is te groot, maximaal ',maxmem,' bytes groot!');
        HALT;
      END;
      FOR tel:=0 TO lengte DO rij[tel+maxpos]:=regel[tel];
      IF LENGTH(regel)>79 THEN rij[maxpos]:=#79;
      maxpos:=maxpos+lengte+2;
      rij[maxpos-1]:=CHAR(lengte);
      DELETE(regel,1,80);
    UNTIL regel='';
  UNTIL EOF(file1);
  CLOSE(file1);
  BouwScherm;
  REPEAT
    READ(KBD,k);
    IF k=#30 THEN ScrolUp;   {cursor omhoog}
    IF k=#31 THEN ScrolDown; {cursor omlaag}
  UNTIL (k=#27) OR (k=#32);  {esc of spatie}
  CLRSCR
END.