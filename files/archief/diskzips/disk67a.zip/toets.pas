PROGRAM Toets;

TYPE letter =
(nul,een,twee,drie,vier,vijf,zes,zeven,
 acht,negen,min,isgelijk,deellinks,rechtopen,rechtsluit,puntkomma,
 acculadeopen,acculadesluit,komma,punt,deelrechts,dodetoets,toetsa,toetsb,
 toetsc,toetsd,toetse,toetsf,toetsg,toetsh,toetsi,toetsj,
 toetsk,toetsl,toetsm,toetsn,toetso,toetsp,toetsq,toetsr,
 toetss,toetst,toetsu,toetsv,toetsw,toetsx,toetsy,toetsz,
 shift,ctrl,graph,caps,code,fun1,fun2,fun3,
 fun4,fun5,esc,tab,stop,backspace,select,return,
 spatie,home,ins,del,cursorl,cursorb,cursoro,cursorr);

CONST naam : ARRAY[letter] OF STRING[10]=
('0'   ,   '1'   ,   '2'   ,   '3'   ,   '4'   ,   '5'   ,   '6'   ,   '7'   ,
 '8'   ,   '9'   ,   '-'   ,   '='   ,   '\'   ,   '['   ,   ']'   ,   ';'   ,
 ''''  ,   '`'   ,   ','   ,   '.'   ,   '/'   ,'DODE TOETS', 'A'   ,   'B'   ,
 'C'   ,   'D'   ,   'E'   ,   'F'   ,   'G'   ,   'H'   ,   'I'   ,   'J'   ,
 'K'   ,   'L'   ,   'M'   ,   'N'   ,   'O'   ,   'P'   ,   'Q'   ,   'R'   ,
 'S'   ,   'T'   ,   'U'   ,   'V'   ,   'W'   ,   'X'   ,   'Y'   ,   'Z'   ,
'SHIFT','CTRL'   ,'GRAPH'  ,'CAPS'   ,'CODE'   ,  'F1'   ,  'F2'   ,  'F3'   ,
'F4'   ,  'F5'   , 'ESC'   , 'TAB'   ,'STOP'   ,'BS'     ,'SELECT' ,'RETURN' ,
'SPATIE','HOME'  ,'INS','DEL','CUR.<','CUR.^','CUR.V','CUR.>T');
VAR toetsen : SET OF letter ABSOLUTE $FBE5;
    telchar : letter;

BEGIN
  REPEAT
    FOR telchar:=nul TO cursorr DO
      IF NOT (telchar IN toetsen) THEN write(naam[telchar]);
  UNTIL NOT (spatie in toetsen);
END.
