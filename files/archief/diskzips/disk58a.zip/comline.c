/* Program : COMLINE.C 
/* Auteur  : Michel Greve 
/* Datum   : 06-10-'92 
/* Doel    : Ditprogramma leest de command line uit.      */ 
/*         : argc geeft het aantal argumenten aan.        */ 
/*         : argv[] is een array van pointers die         */ 
/*         : wijzen naar het begin van de opgegeven       */ 
/*         : argumenten. argv[] wordt niet gebruikt       */ 
 
#include CRUN2   .LIB 
#include CONIO2  .LIB 
 
/* Dit programma zet de argumenten die zijn meegegeven    */ 
/* onder elkaar op he scherm                              */ 
/* teller begint bij 1, omdat argv[0] niet wordt gebruikt.*/ 
 
main(argc,argv) 
int argc,argv[]; 
{ 
   char teller; 
 
   teller=1; 
   while(teller!=argc) 
   { 
    puts(argv[teller]);puts(<169>\n<170>); 
    teller++1; 
   } 
} 
