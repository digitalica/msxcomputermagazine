100 ' ; BINTYPE
110 ' ; Een toepassing van LogOps
120 '
130 ' equ CHPUT ,$00A2
140 ' equ CHGET ,$009F
150 '
160 ' org $C000
170 '
180 ' START:
190 '   call CHGET
200 '   and 1
210 '   or 48
220 '   call CHPUT
230 '   jp START
