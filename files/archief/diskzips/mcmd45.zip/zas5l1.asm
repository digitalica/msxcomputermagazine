100 ' ; HOOFDLETTERS
110 ' ; Een toepassing van AND
120 '
130 ' equ CHPUT ,$00A2
140 ' equ CHGET ,$009F
150 '
160 ' org $C000
170 '
180 ' START:
190 '   call CHGET
200 '   and 223
210 '   call CHPUT
220 '   jp START
