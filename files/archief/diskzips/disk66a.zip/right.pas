PROGRAM Sort;

VAR oudconin,oudconout : INTEGER;
    regel  : STRING[80];
    letter : CHAR;
    return : BOOLEAN;

{ charout stuurt een karakter naar de standaard uitvoer }
PROCEDURE CharOut(ch : CHAR);
BEGIN
  INLINE($3A/ch/      { LD A,(ch)  neem karakter                       }
         $5F/         { LD E,A     plaats dat in register 'E'          }
         $0E/$02/     { LD C,2     vul register 'C' met dos functienr  }
         $CD/$05/$00) { CALL 05    roep dos aan                        }
END;

{ charin leest een karakter van de standaard invoer }
FUNCTION CharIn : CHAR;
VAR ch : CHAR;
BEGIN
  INLINE($0E/$07/     { LD C,7     vul register 'C' met dos functie _DIRIN }
         $CD/$05/$00/ { CALL 05    roep dos aan                            }
         $32/ch);     { LD (ch),A  zet binnengekomen karakter in 'ch'      }
  CharIn:=ch
END;

{notendoffile kijkt of het einde van de invoer is bereikt. Dit wordt gedaan
 door de status van de handler op te vragen en die op een bit te controleren }
FUNCTION NotEndOfFile : BOOLEAN;
VAR list : INTEGER;
BEGIN
  INLINE($0E/$4B/      { LD C,4bH   vul register 'C' met dos functie _ioctl }
         $06/$00/      { LD B,0     vul register 'B' met file handle        }
         $3e/$00/      { LD A,0     sub functie -get file handle status-    }
         $CD/$05/$00/  { CALL 05    roep dos aan                            }
         $ED/$53/list);{ LD (list),DE zet uitkomst in list                  }
  NotEndOfFile:=(list AND 64)<>64       { bit 7 geSET dan einde van de file }
END;

{ inputdevice kijkt via een dos call welke status de standaard invoer heeft }
FUNCTION InputDevice : BOOLEAN;
VAR list : INTEGER;
BEGIN
  INLINE($0E/$4B/      { LD C,4bH   vul register 'C' met dos functie _ioctl }
         $06/$00/      { LD B,0     vul register 'B' met file handle        }
         $3e/$00/      { LD A,0     sub functie -get file handle status-    }
         $CD/$05/$00/  { CALL 05    roep dos aan                            }
         $ED/$53/list);{ LD (list),DE zet uitkomst in list                  }
  InputDevice:=(list AND 128)=128            { zo niet, dan is het een file }
END;

{ outputdevice is gelijk aan inputdevice, alleen het nummer van de file-
  handler is anders. Onder dos is file handle 1 altijd de standaaard uitvoer
  en file handle 0 de standaard invoer                                      }
FUNCTION OutputDevice : BOOLEAN;
VAR list : INTEGER;
BEGIN
  INLINE($0E/$4B/      { LD C,4bH   vul register 'C' met dos functie _ioctl }
         $06/$01/      { LD B,1     vul register 'B' met file handle        }
         $3e/$00/      { LD A,0     sub functie -get file handle status-    }
         $CD/$05/$00/  { CALL 05    roep dos aan                            }
         $ED/$53/list);{ LD (list),DE zet uitkomst in list                  }
  InputDevice:=(list AND 128)=128            { zo niet, dan is het een file }
END;

PROCEDURE SchrijfRegel;
BEGIN
  IF regel<>'' THEN WRITELN(regel:79);
END;

PROCEDURE PushLetter(k:CHAR);
BEGIN
  IF k=#13 THEN
  BEGIN
    IF return THEN regel:=regel+#13;
    return:=TRUE;
    EXIT
  END;
  IF return AND (k<>#10) THEN
  BEGIN
    regel:=regel+#13+k;
    return:=FALSE;
    EXIT
  END;
  IF return AND (k=#10) THEN
  BEGIN
    SchrijfRegel;
    regel:='';
    return:=FALSE;
    EXIT
  END;
  regel:=regel+k;
  return:=FALSE;
END;

BEGIN
  oudconin:=CONINPTR;
  oudconout:=CONOUTPTR;
  IF InputDevice THEN WRITELN('vanaf toetsenbord')
  ELSE WRITELN('uit een file');
  IF OutputDevice THEN WRITELN('naar een file')
  ELSE WRITELN('naar het beeldscherm');
  CONOUTPTR:=ADDR(CharOut);
  CONINPTR:=ADDR(CharIn);
  return:=FALSE;
  regel:='';
  IF InputDevice THEN
  REPEAT
    READ(KBD,letter);
  UNTIL EOF(kbd);
  WHILE NotEndOfFile DO
  BEGIN
    read(KBD,letter);
    PushLetter(letter);
  END;
  Schrijfregel;
  CONINPTR:=oudconin;
  CONOUTPTR:=oudconout;
END.
